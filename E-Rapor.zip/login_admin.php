<?php
session_start();
include 'koneksi.php';

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($koneksi, $_POST['user']);
    $password = $_POST['pass'];

    // 1. Query mencari ke tabel 'admin' sesuai screenshot Anda
    $query = mysqli_query($koneksi, "SELECT * FROM admin WHERE username='$username'");
    $data = mysqli_fetch_assoc($query);

    if ($data) {
        // 2. Cek Password. 
        // Karena di screenshot Anda password berisi teks/MD5, 
        // kita gunakan perbandingan MD5 atau teks langsung.
        if (md5($password) == $data['password'] || $password == $data['password']) {
            
            // SET SESSION agar data_guru.php bisa terbuka
            $_SESSION['admin_login'] = true;
            $_SESSION['admin_nama'] = $data['nama_lengkap'];
            
            header("Location: data_guru.php");
            exit;
        } else {
            $error = "Password Administrator Salah!";
        }
    } else {
        $error = "Username Admin tidak ditemukan di tabel admin!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login Admin - Panel Kendali</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #090909; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; color: white; }
        .login-card { background: #151515; padding: 40px; border-radius: 20px; width: 360px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); border: 1px solid #222; text-align: center; }
        .login-card i.main-icon { font-size: 50px; color: #007bff; margin-bottom: 20px; }
        .input-group { background: #202020; border: 1px solid #333; border-radius: 10px; padding: 12px 15px; margin-bottom: 15px; display: flex; align-items: center; }
        .input-group input { background: transparent; border: none; color: white; outline: none; width: 100%; font-size: 15px; }
        .btn-login { background: #007bff; color: white; border: none; width: 100%; padding: 14px; border-radius: 10px; font-weight: bold; cursor: pointer; }
        .error-msg { background: rgba(220, 53, 69, 0.1); color: #ff4d4d; padding: 10px; border-radius: 8px; font-size: 13px; margin-bottom: 20px; border: 1px solid rgba(220, 53, 69, 0.2); }
    </style>
</head>
<body>

<div class="login-card">
    <i class="fas fa-user-shield main-icon"></i>
    <h2>Admin Login</h2>
    
    <?php if(isset($error)): ?>
        <div class="error-msg">
            <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
        </div>
    <?php endif; ?>

    <form method="POST">
        <div class="input-group">
            <i class="fas fa-user" style="margin-right:10px;"></i>
            <input type="text" name="user" placeholder="Username" required>
        </div>
        <div class="input-group">
            <i class="fas fa-lock" style="margin-right:10px;"></i>
            <input type="password" name="pass" placeholder="Password" required>
        </div>
        <button type="submit" name="login" class="btn-login">MASUK KE PANEL</button>
    </form>
</div>

</body>
</html>