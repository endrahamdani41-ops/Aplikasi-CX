<?php
// Baris di bawah ini untuk memunculkan pesan error jika ada yang salah
// Hapus atau beri komentar jika sudah berhasil
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include 'koneksi.php';

if (!isset($_SESSION['login'])) {
    header("Location: login_guru.php");
    exit;
}

$username = $_SESSION['username'];

// Ambil data guru
$query = mysqli_query($koneksi, "SELECT * FROM guru WHERE username = '$username'");
$data = mysqli_fetch_assoc($query);

// Proses Update
if (isset($_POST['update'])) {
    $nama  = mysqli_real_escape_string($koneksi, $_POST['nama_guru']);
    $nip   = mysqli_real_escape_string($koneksi, $_POST['nip']);
    $mapel = mysqli_real_escape_string($koneksi, $_POST['mapel']);
    $kelas = mysqli_real_escape_string($koneksi, $_POST['wali_kelas']);
    
    $sql = "UPDATE guru SET 
            nama_guru = '$nama', 
            nip = '$nip', 
            mapel = '$mapel',
            wali_kelas = '$kelas' 
            WHERE username = '$username'";
            
    $update = mysqli_query($koneksi, $sql);
    
    if ($update) {
        echo "<script>alert('Profil Berhasil Diperbarui!'); window.location='profil.php';</script>";
        exit;
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Profil - Dark Mode</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { font-family: sans-serif; background-color: #0f172a; color: #f8fafc; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .card { background: #1e293b; width: 100%; max-width: 400px; padding: 30px; border-radius: 20px; border: 1px solid #334155; }
        h2 { text-align: center; color: #3b82f6; margin-bottom: 20px; }
        .group { margin-bottom: 15px; }
        label { display: block; font-size: 12px; color: #94a3b8; margin-bottom: 5px; }
        input { width: 100%; padding: 10px; background: #0f172a; border: 1px solid #334155; border-radius: 10px; color: white; box-sizing: border-box; }
        button { width: 100%; padding: 12px; background: #3b82f6; color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: bold; margin-top: 10px; }
        .back { display: block; text-align: center; margin-top: 15px; color: #94a3b8; text-decoration: none; font-size: 13px; }
    </style>
</head>
<body>
    <div class="card">
        <h2>Edit Profil</h2>
        <form method="POST">
            <div class="group">
                <label>Nama Lengkap</label>
                <input type="text" name="nama_guru" value="<?= $data['nama_guru'] ?? '' ?>" required>
            </div>
            <div class="group">
                <label>NIP</label>
                <input type="text" name="nip" value="<?= $data['nip'] ?? '' ?>" required>
            </div>
            <div class="group">
                <label>Mata Pelajaran</label>
                <input type="text" name="mapel" value="<?= $data['mapel'] ?? '' ?>" required>
            </div>
            <div class="group">
                <label>Wali Kelas</label>
                <input type="text" name="wali_kelas" value="<?= $data['wali_kelas'] ?? '' ?>" required>
            </div>
            <button type="submit" name="update">SIMPAN PERUBAHAN</button>
            <a href="profil.php" class="back">Batal</a>
        </form>
    </div>
</body>
</html>