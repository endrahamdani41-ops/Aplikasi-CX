<?php
session_start();
include 'koneksi.php';

// Menangkap parameter kelas dari URL (Misal: ?kelas=8F)
$kelas_pilihan = isset($_GET['kelas']) ? mysqli_real_escape_string($koneksi, $_GET['kelas']) : '';
$mapel = isset($_SESSION['mapel']) ? $_SESSION['mapel'] : 'INFORMATIKA';

// Validasi jika parameter kelas kosong
if (empty($kelas_pilihan)) {
    echo "<div style='text-align:center; padding:50px; font-family:sans-serif;'>
            <h2>⚠️ Data Kelas Tidak Ditemukan</h2>
            <p>Silakan kembali ke halaman input nilai dan klik tombol cetak dari sana.</p>
            <a href='input_nilai.php'>Kembali ke Pilih Kelas</a>
          </div>";
    exit;
}

// Query mengambil data nilai berdasarkan kelas dan mapel
$sql = "SELECT * FROM nilai WHERE kelas = '$kelas_pilihan' AND mapel = '$mapel' ORDER BY nama_murid ASC";
$query = mysqli_query($koneksi, $sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cetak Rapor - Kelas <?= $kelas_pilihan ?></title>
    <style>
        body { font-family: 'Times New Roman', serif; padding: 30px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid black; padding: 8px; text-align: center; }
        .text-left { text-align: left; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body>

    <div class="no-print">
        <a href="dashboard_guru.php?page=input_nilai" class="bg-gray-900 hover:bg-gray-800 text-white px-5 py-2 rounded-xl text-xs font-bold transition">
                <i class="fas fa-arrow-left mr-2"></i> Kembali
            </a>
        <button onclick="window.print()">🖨️ Cetak Sekarang</button>
        <hr>
         
    </div>

    <div style="text-align: center;">
        <h2 style="margin:0;">DAFTAR NILAI PESERTA DIDIK</h2>
        <p>Mata Pelajaran: <?= $mapel ?> | Kelas: <?= $kelas_pilihan ?></p>
    </div>

    <table>
        <thead>
            <tr style="background: #f2f2f2;">
                <th>NO</th>
                <th>NIS</th>
                <th>NAMA MURID</th>
                <th>UH 1</th>
                <th>UH 2</th>
                <th>ASTS</th>
                <th>RATA-RATA</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $no = 1;
            while($row = mysqli_fetch_array($query)) { 
                $rata = ($row['uh1'] + $row['uh2'] + $row['asts']) / 3;
            ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $row['nis'] ?></td>
                <td class="text-left"><?= strtoupper($row['nama_murid']) ?></td>
                <td><?= $row['uh1'] ?></td>
                <td><?= $row['uh2'] ?></td>
                <td><?= $row['asts'] ?></td>
                <td><?= number_format($rata, 1) ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>