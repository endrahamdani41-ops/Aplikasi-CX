<?php
session_start();
include 'koneksi.php';

// --- 1. AMBIL STATISTIK RINGKAS ---
$q_siswa = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM siswa");
$t_siswa = mysqli_fetch_assoc($q_siswa)['total'];

$q_guru = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM guru");
$t_guru = mysqli_fetch_assoc($q_guru)['total'];

$q_kelas = mysqli_query($koneksi, "SELECT COUNT(DISTINCT kelas) as total FROM siswa");
$t_kelas = mysqli_fetch_assoc($q_kelas)['total'];

// --- 2. DATA TABEL MONITORING ---
$list_kelas = mysqli_query($koneksi, "SELECT kelas, COUNT(*) as jml FROM siswa GROUP BY kelas ORDER BY kelas ASC");

/** * PERBAIKAN QUERY: 
 * 1. Menggunakan TRIM & UPPER agar deteksi PPKN/PKN lebih akurat.
 * 2. Menggunakan FIELD() agar urutan sesuai standar Kurikulum Merdeka.
 */
$list_guru = mysqli_query($koneksi, "SELECT 
    CASE 
        WHEN UPPER(TRIM(mapel)) IN ('PPKN', 'PKN', 'PENDIDIKAN PANCASILA DAN KEWARGANEGARAAN') THEN 'PENDIDIKAN PANCASILA'
        ELSE UPPER(TRIM(mapel)) 
    END as mapel_bersih, 
    COUNT(*) as jml 
    FROM guru 
    WHERE mapel IS NOT NULL AND TRIM(mapel) != '' 
    GROUP BY mapel_bersih 
    ORDER BY FIELD(mapel_bersih, 
        'PENDIDIKAN AGAMA ISLAM', 
        'PENDIDIKAN AGAMA KRISTEN',
        'PENDIDIKAN PANCASILA', 
        'BAHASA INDONESIA', 
        'MATEMATIKA', 
        'IPA', 
        'IPS', 
        'BAHASA INGGRIS', 
        'PJOK', 
        'INFORMATIKA', 
        'SENI BUDAYA', 
        'PRAKARYA',
        'MUATAN LOKAL'
    ) ASC, mapel_bersih ASC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin | SMPN 110 Jakarta</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --bg: #000;
            --card: #0a0a0a;
            --border: #222;
            --purple: #a855f7;
            --green: #22c55e;
            --text: #fff;
            --dim: #71717a;
        }

        body { font-family: 'Inter', sans-serif; background: var(--bg); color: var(--text); margin: 0; padding: 25px; }
        .container { max-width: 1200px; margin: 0 auto; }

        /* Header */
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid var(--border); }
        .header h1 { font-size: 1.3rem; font-weight: 700; margin: 0; display: flex; align-items: center; gap: 10px; }
        .header h1 i { color: var(--purple); }
        .logout-btn { background: #ef4444; color: white; padding: 8px 16px; border-radius: 8px; text-decoration: none; font-size: 0.8rem; font-weight: bold; transition: 0.3s; }
        .logout-btn:hover { background: #b91c1c; }

        /* Stats Card */
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: var(--card); border: 1px solid var(--border); padding: 25px; border-radius: 16px; position: relative; overflow: hidden; }
        .stat-card .label { color: var(--dim); font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; }
        .stat-card .number { font-size: 2.2rem; font-weight: 800; margin: 8px 0; display: block; }
        .stat-card i.icon-bg { position: absolute; right: -10px; bottom: -10px; font-size: 5rem; opacity: 0.05; }

        /* Navigation Menu */
        .menu-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 40px; }
        .menu-item { background: var(--card); border: 1px solid var(--border); padding: 20px; border-radius: 16px; text-decoration: none; color: var(--text); display: flex; align-items: center; gap: 15px; transition: 0.2s; }
        .menu-item:hover { border-color: var(--purple); background: #0f0f0f; transform: translateY(-2px); }
        .menu-icon { width: 45px; height: 45px; border-radius: 10px; background: #1a1a1a; display: flex; align-items: center; justify-content: center; color: var(--purple); font-size: 1.1rem; }
        .menu-info h3 { margin: 0; font-size: 0.95rem; }
        .menu-info p { margin: 3px 0 0 0; font-size: 0.75rem; color: var(--dim); }

        /* Tables Monitoring */
        .tables-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 25px; }
        .content-card { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 20px; }
        .content-card h2 { font-size: 0.9rem; margin-top: 0; margin-bottom: 20px; color: var(--purple); text-transform: uppercase; }

        .table-wrapper { max-height: 380px; overflow-y: auto; }
        .table-wrapper::-webkit-scrollbar { width: 4px; }
        .table-wrapper::-webkit-scrollbar-thumb { background: #333; border-radius: 10px; }

        table { width: 100%; border-collapse: collapse; }
        th { text-align: left; padding: 12px; color: var(--dim); font-size: 0.7rem; border-bottom: 1px solid var(--border); position: sticky; top: 0; background: var(--card); z-index: 2; }
        td { padding: 12px; font-size: 0.85rem; border-bottom: 1px solid #111; }
        .badge { background: #1e3a8a; color: #60a5fa; padding: 3px 8px; border-radius: 4px; font-size: 0.65rem; font-weight: 700; }

        @media (max-width: 850px) { .tables-grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1><i class="fas fa-shapes"></i> DASHBOARD SISTEM E-RAPOR</h1>
        <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> KELUAR</a>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <span class="label">Total Siswa</span>
            <span class="number"><?php echo $t_siswa; ?></span>
            <span style="color: var(--green); font-size: 0.7rem;"><i class="fas fa-check-circle"></i> Data Sinkron</span>
            <i class="fas fa-user-graduate icon-bg"></i>
        </div>
        <div class="stat-card">
            <span class="label">Total Guru</span>
            <span class="number"><?php echo $t_guru; ?></span>
            <span style="color: var(--purple); font-size: 0.7rem;"><i class="fas fa-id-badge"></i> Sertifikasi Aktif</span>
            <i class="fas fa-chalkboard-teacher icon-bg"></i>
        </div>
        <div class="stat-card">
            <span class="label">Total Kelas</span>
            <span class="number"><?php echo $t_kelas; ?></span>
            <span style="color: #3b82f6; font-size: 0.7rem;"><i class="fas fa-door-open"></i> Ruang Belajar</span>
            <i class="fas fa-school icon-bg"></i>
        </div>
    </div>

    <div class="menu-grid">
        <a href="data_siswa.php" class="menu-item">
            <div class="menu-icon"><i class="fas fa-users-viewfinder"></i></div>
            <div class="menu-info">
                <h3>Database Siswa</h3>
                <p>Edit & Manajemen Siswa</p>
            </div>
        </a>
        <a href="data_guru.php" class="menu-item">
            <div class="menu-icon"><i class="fas fa-user-shield"></i></div>
            <div class="menu-info">
                <h3>Data Guru</h3>
                <p>Pengaturan Pengampu Mapel</p>
            </div>
        </a>
        <a href="rekap_nilai.php" class="menu-item">
            <div class="menu-icon"><i class="fas fa-chart-line"></i></div>
            <div class="menu-info">
                <h3>Rekap Nilai</h3>
                <p>Monitoring Hasil Belajar</p>
            </div>
        </a>
    </div>

    <div class="tables-grid">
        <div class="content-card">
            <h2><i class="fas fa-users-class"></i> Siswa per Kelas</h2>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr><th>ROMBEL</th><th>JUMLAH</th><th>STATUS</th></tr>
                    </thead>
                    <tbody>
                        <?php while($c = mysqli_fetch_assoc($list_kelas)) : ?>
                        <tr>
                            <td><strong>KELAS <?php echo $c['kelas']; ?></strong></td>
                            <td><?php echo $c['jml']; ?> Siswa</td>
                            <td><span class="badge">AKTIF</span></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="content-card">
            <h2><i class="fas fa-book-bookmark"></i> Guru per Mapel (Urutan Kurmer)</h2>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr><th>MATA PELAJARAN</th><th style="text-align:right;">PENGAMPU</th></tr>
                    </thead>
                    <tbody>
                        <?php 
                        if(mysqli_num_rows($list_guru) > 0) {
                            while($g = mysqli_fetch_assoc($list_guru)) : 
                        ?>
                        <tr>
                            <td style="font-weight: 500;"><?php echo $g['mapel_bersih']; ?></td>
                            <td style="text-align:right; color:var(--purple); font-weight:bold;">
                                <?php echo $g['jml']; ?> Orang
                            </td>
                        </tr>
                        <?php 
                            endwhile; 
                        } else {
                            echo "<tr><td colspan='2' style='text-align:center; padding:20px; color:var(--dim);'>Belum ada data mapel</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

</body>
</html>