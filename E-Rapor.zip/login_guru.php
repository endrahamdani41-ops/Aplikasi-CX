<?php
// 1. PASTIKAN TIDAK ADA SPASI SEBELUM TAG PHP INI
session_start();
include 'koneksi.php';

// Jika sudah ada session login, langsung pindah ke dashboard
if (isset($_SESSION['login']) && $_SESSION['login'] === true) {
    header("Location: dashboard_guru.php");
    exit;
}

$error = false;

if (isset($_POST['login'])) {
    // Ambil data dan amankan dari SQL Injection
    $username = mysqli_real_escape_string($koneksi, trim($_POST['username']));
    $password = $_POST['password'];
    $role_pilihan = mysqli_real_escape_string($koneksi, $_POST['role']);

    /**
     * PENTING: Menggunakan tabel 'password_guru' sesuai screenshot database Anda.
     * Mengizinkan login menggunakan kolom 'username' atau 'nip'.
     */
    $query = "SELECT * FROM password_guru WHERE (username = '$username' OR nip = '$username') AND role = '$role_pilihan' LIMIT 1";
    $result = mysqli_query($koneksi, $query);

    if ($result && mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        
        // Cek apakah password cocok (Mendukung teks biasa & password_hash)
        if ($password === $row['password'] || password_verify($password, $row['password'])) {
            
            // Simpan semua data penting ke Session
            $_SESSION['login']   = true;
            $_SESSION['id_guru'] = $row['id'];
            $_SESSION['nama']    = $row['nama_guru'];
            $_SESSION['kelas']   = $row['kelas_ampu'];
            $_SESSION['role']    = $row['role'];
            $_SESSION['mapel']   = strtolower($row['mapel']); // Lowercase untuk sinkronisasi sistem nilai

            // Lempar ke dashboard
            header("Location: dashboard_guru.php");
            exit;
        } else {
            $error = "Password salah! Periksa kembali besar kecil huruf.";
        }
    } else {
        $error = "Akun tidak ditemukan atau Peran (Role) tidak sesuai!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Guru - E-Rapor Digital</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background-color: #0f0f0f; color: white; font-family: 'Inter', sans-serif; }
        .login-box { background-color: #1a1a1a; border: 1px solid #333; }
        input:focus { border-color: #a855f7 !important; }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen p-4">

<div class="login-box w-full max-w-sm p-10 rounded-3xl shadow-2xl text-center">
    <div class="w-20 h-20 bg-purple-600/10 rounded-full flex items-center justify-center mx-auto mb-6">
        <i class="fas fa-user-shield text-4xl text-purple-500"></i>
    </div>
    <h2 class="text-2xl font-bold mb-2">LOGIN GURU</h2>
    <p class="text-gray-500 text-xs mb-8 uppercase tracking-widest">Panel Manajemen Nilai</p>

    <?php if ($error) : ?>
        <div class="bg-red-500/10 border border-red-500/50 text-red-500 text-xs p-4 rounded-xl mb-6 text-left flex items-center gap-3">
            <i class="fas fa-circle-exclamation text-lg"></i>
            <span><?php echo $error; ?></span>
        </div>
    <?php endif; ?>

    <form action="" method="post" class="text-left space-y-5">
        <div>
            <label class="text-gray-400 text-[10px] font-bold uppercase tracking-wider block mb-2 ml-1">Username / NIP</label>
            <input type="text" name="username" placeholder="Masukkan Username/NIP" class="w-full bg-[#252525] border border-gray-800 p-4 rounded-xl outline-none transition" required autofocus>
        </div>
        
        <div>
            <label class="text-gray-400 text-[10px] font-bold uppercase tracking-wider block mb-2 ml-1">Password</label>
            <input type="password" name="password" placeholder="••••••••" class="w-full bg-[#252525] border border-gray-800 p-4 rounded-xl outline-none transition" required>
        </div>

        <div>
            <label class="text-gray-400 text-[10px] font-bold uppercase tracking-wider block mb-2 ml-1">Login Sebagai</label>
            <select name="role" class="w-full bg-[#252525] border border-gray-800 p-4 rounded-xl outline-none transition cursor-pointer appearance-none" required>
                <option value="mapel">Guru Mata Pelajaran</option>
                <option value="walikelas">Guru Wali Kelas</option>
            </select>
        </div>

        <button type="submit" name="login" class="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-4 rounded-xl transition transform active:scale-95 shadow-xl shadow-purple-900/20 uppercase tracking-widest text-sm">
            Masuk Sekarang
        </button>
    </form>
</div>

</body>
</html>