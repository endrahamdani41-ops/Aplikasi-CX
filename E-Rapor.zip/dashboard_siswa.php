<?php
// Wajib di baris pertama tanpa spasi/baris kosong di atasnya
session_start();
include 'koneksi.php';

// Proteksi login
if (!isset($_SESSION['login']) || !isset($_SESSION['nis'])) {
    header("Location: login_siswa.php");
    exit;
}

$nama_siswa = $_SESSION['nama'];
$nis_siswa  = $_SESSION['nis'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Siswa | E-Rapor Digital</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #0f172a; font-family: 'Inter', sans-serif; color: #f8fafc; }
        .glass-card { background: #1e293b; border: 1px solid #334155; }
        .hover-purple:hover { border-color: #a855f7; transform: translateY(-5px); transition: all 0.3s ease; }
    </style>
</head>
<body class="min-h-screen">

    <header class="border-b border-slate-800 bg-[#0f172a]/80 backdrop-blur-md sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
            <div class="flex items-center gap-3">
                <div class="bg-purple-600 p-2 rounded-xl shadow-lg shadow-purple-900/20">
                    <i class="fas fa-graduation-cap text-white text-xl"></i>
                </div>
                <h1 class="text-xl font-bold tracking-tight text-white uppercase hidden sm:block">E-Rapor <span class="text-purple-500">Siswa</span></h1>
            </div>
            <div class="flex items-center gap-4">
                <div class="text-right hidden md:block">
                    <p class="text-sm font-bold text-white"><?php echo $nama_siswa; ?></p>
                    <p class="text-[10px] text-slate-500 uppercase tracking-widest italic">NIS: <?php echo $nis_siswa; ?></p>
                </div>
                <a href="logout.php" class="bg-red-500/10 hover:bg-red-500 text-red-500 hover:text-white p-2.5 rounded-xl transition-all border border-red-500/20">
                    <i class="fas fa-power-off"></i>
                </a>
            </div>
        </div>
    </header>

    <main class="max-w-7xl mx-auto p-6 space-y-6">
        
        <section class="relative overflow-hidden bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900 rounded-[2rem] p-8 md:p-10 shadow-2xl border border-white/10">
            <div class="relative z-10">
                <span class="bg-purple-500/20 text-purple-300 text-[10px] font-bold px-3 py-1 rounded-full border border-purple-500/30 uppercase tracking-widest">Siswa Aktif</span>
                
                <h2 class="text-base md:text-2xl font-black text-white mt-4 mb-1 tracking-tight whitespace-nowrap overflow-hidden text-ellipsis">
                    Selamat Datang, <span class="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-300 uppercase"><?php echo $nama_siswa; ?></span>!
                </h2>
                
                <p class="text-slate-400 text-xs md:text-sm">Pantau hasil belajar dan perkembangan nilai kamu di sini.</p>
            </div>
            <i class="fas fa-rocket absolute right-6 bottom-[-10px] text-[100px] text-white/5 -rotate-12"></i>
        </section>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
            <a href="lihat_rapor.php" class="glass-card p-6 rounded-3xl flex items-center gap-5 hover-purple">
                <div class="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center border border-blue-500/20 text-blue-400">
                    <i class="fas fa-file-invoice text-xl"></i>
                </div>
                <div>
                    <h3 class="font-bold text-white text-sm">Lihat Rapor</h3>
                    <p class="text-[10px] text-slate-500 italic">Cek Nilai Semester</p>
                </div>
            </a>

            <a href="ganti_password_siswa.php" class="glass-card p-6 rounded-3xl flex items-center gap-5 hover-purple">
                <div class="w-12 h-12 bg-yellow-500/10 rounded-2xl flex items-center justify-center border border-yellow-500/20 text-yellow-400">
                    <i class="fas fa-key text-xl"></i>
                </div>
                <div>
                    <h3 class="font-bold text-white text-sm">Keamanan Akun</h3>
                    <p class="text-[10px] text-slate-500 italic">Ganti Password</p>
                </div>
            </a>

            <div class="glass-card p-6 rounded-3xl flex items-center gap-5 border-dashed border-slate-700">
                <div class="w-12 h-12 bg-green-500/10 rounded-2xl flex items-center justify-center border border-green-500/20 text-green-400">
                    <i class="fas fa-bullhorn text-xl"></i>
                </div>
                <div>
                    <h3 class="font-bold text-white text-sm">Info Sekolah</h3>
                    <p class="text-[10px] text-slate-500 italic">Belum ada kabar</p>
                </div>
            </div>
        </div>

        <footer class="text-center py-6">
            <p class="text-slate-600 text-[10px] uppercase tracking-widest font-bold">
                &copy; 2026 E-Rapor Digital • SMPN 110 JAKARTA
            </p>
        </footer>

    </main>
</body>
</html>