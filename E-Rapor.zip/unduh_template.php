<?php
session_start();
include 'koneksi.php';

// 1. PROTEKSI HALAMAN
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    exit("Akses ditolak.");
}

// 2. AMBIL PARAMETER (DARI URL)
// Pastikan tombol unduh di halaman input_nilai.php mengirimkan parameter ini
$kelas = isset($_GET['kelas']) ? mysqli_real_escape_string($conn, $_GET['kelas']) : '';
$mapel = isset($_SESSION['mapel']) ? $_SESSION['mapel'] : 'Mata_Pelajaran';

if (empty($kelas)) {
    exit("Error: Kelas tidak ditentukan.");
}

// 3. SET NAMA FILE DINAMIS
// Ini yang memperbaiki masalah "8A" Anda. Nama file akan otomatis berubah.
$filename = "Template_Nilai_" . str_replace(' ', '_', $mapel) . "_Kelas_" . $kelas . ".csv";

// 4. HEADER UNTUK DOWNLOAD CSV
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=' . $filename);

// 5. MEMBUAT ISI FILE
$output = fopen('php://output', 'w');

// Header Kolom di Excel/CSV
fputcsv($output, array('NOMOR_INDUK', 'NAMA_LENGKAP', 'PH1', 'PH2', 'PTS'));

// 6. AMBIL DATA SISWA DARI DATABASE BERDASARKAN KELAS
// Menggunakan tabel 'users' dan kolom 'nama_lengkap' sesuai database Anda
$query = mysqli_query($conn, "SELECT nomor_induk, nama_lengkap 
                              FROM users 
                              WHERE kelas = '$kelas' AND role = 'siswa' 
                              ORDER BY nama_lengkap ASC");

while ($row = mysqli_fetch_assoc($query)) {
    // PH1, PH2, dan PTS dikosongkan agar guru bisa mengisi di Excel
    fputcsv($output, array($row['nomor_induk'], $row['nama_lengkap'], '', '', ''));
}

fclose($output);
exit;
?>