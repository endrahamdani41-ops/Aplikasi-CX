<?php
session_start();
include 'koneksi.php';
if (!isset($_SESSION['login_admin'])) { header("Location: login_admin.php"); exit; }

// Fitur Pencarian & Filter Kelas
$where = "";
if (isset($_GET['filter_kelas']) && $_GET['filter_kelas'] != "") {
    $kls = $_GET['filter_kelas'];
    $where = "WHERE kelas = '$kls'";
}

$query_siswa = mysqli_query($koneksi, "SELECT * FROM nilaisiswa $where ORDER BY kelas ASC, nama ASC");
$list_kelas = mysqli_query($koneksi, "SELECT DISTINCT kelas FROM nilaisiswa ORDER BY kelas ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Seluruh Siswa</title>
    <style>
        body { font-family: sans-serif; background: #f4f7f6; margin: 0; }
        .nav { background: #34495e; padding: 15px; color: white; }
        .nav a { color: white; text-decoration: none; margin-right: 20px; }
        .container { padding: 20px; }
        .filter-box { margin-bottom: 20px; background: white; padding: 15px; border-radius: 5px; border: 1px solid #ddd; }
        table { width: 100%; border-collapse: collapse; background: white; font-size: 14px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background: #34495e; color: white; }
        .badge-kelas { background: #17a2b8; color: white; padding: 3px 8px; border-radius: 10px; font-size: 11px; }
    </style>
</head>
<body>
    <div class="nav">
        <a href="dashboard_admin.php">Beranda</a>
        <a href="data_guru.php">Kelola Guru</a>
        <a href="data_siswa_all.php"><b>Semua Siswa</b></a>
        <a href="logout.php" style="float:right;">Logout</a>
    </div>

    <div class="container">
        <h2>Data Seluruh Siswa</h2>

        <div class="filter-box">
            <form method="GET">
                Filter Kelas: 
                <select name="filter_kelas" onchange="this.form.submit()" style="padding:5px;">
                    <option value="">-- Tampilkan Semua --</option>
                    <?php while($k = mysqli_fetch_assoc($list_kelas)): ?>
                        <option value="<?= $k['kelas'] ?>" <?= (isset($_GET['filter_kelas']) && $_GET['filter_kelas'] == $k['kelas']) ? 'selected' : '' ?>><?= $k['kelas'] ?></option>
                    <?php endwhile; ?>
                </select>
            </form>
        </div>

        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Siswa</th>
                    <th>NIS</th>
                    <th>Kelas</th>
                    <th>Password Akun</th>
                </tr>
            </thead>
            <tbody>
                <?php $no=1; while($s = mysqli_fetch_assoc($query_siswa)): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><strong><?= $s['nama'] ?></strong></td>
                    <td><?= $s['nis'] ?></td>
                    <td><span class="badge-kelas"><?= $s['kelas'] ?></span></td>
                    <td><?= $s['password'] ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>