<?php 
session_start();
if (!isset($_SESSION['login'])) { header("Location: login.php"); exit; }
?>
<?php include 'koneksi_barang.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Inventaris</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
    <div class="container">
        <a class="navbar-brand" href="stok.php">MyStock</a>
        <div class="navbar-nav">
            <a class="nav-link" href="tambah_barang.php">Tambah Barang</a>
            <a class="nav-link" href="tambah_transaksi.php">Input Transaksi</a>
            <a class="nav-link" href="riwayat.php">Riwayat</a>
            <div class="navbar-nav ms-auto">
    <a class="nav-link btn btn-info text-white me-2" href="cetak_laporan.php" target="_blank">Cetak Laporan</a>
    <a class="nav-link btn btn-warning text-dark me-2" href="backup.php">Backup Database</a>
    <a class="nav-link btn btn-danger text-white" href="logout.php">Logout</a>
</div>
        </div>
    </div>
</nav>

<div class="container">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Sisa Persediaan Barang</h5>
        </div>
        <div class="card-body">
            <table class="table table-hover">
                <thead class="table-light">
                    
                    <tr>
                        <th>ID</th>
                        <th>Nama Barang</th>
                        <th>Awal</th>
                        <th>Masuk</th>
                        <th>Keluar</th>
                        <th>Sisa Stok</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = mysqli_query($conn, "SELECT * FROM barang");
                    while($data = mysqli_fetch_array($query)){
    $status_warna = ($data['stok_akhir'] < 5) ? 'text-danger fw-bold' : '';
    echo "<tr>
            <td>{$data['id_barang']}</td>
            <td>{$data['nama_barang']}</td>
            <td>{$data['stok_awal']}</td>
            <td class='text-success'>+{$data['barang_masuk']}</td>
            <td class='text-danger'>-{$data['barang_keluar']}</td>
            <td class='$status_warna'>{$data['stok_akhir']}</td>
            <td>
                <a href='hapus_barang.php?id={$data['id_barang']}' 
                   class='btn btn-sm btn-danger' 
                   onclick='return confirm(\"Hapus barang ini dan semua riwayatnya?\")'>Hapus</a>
            </td>
          </tr>";
}
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>