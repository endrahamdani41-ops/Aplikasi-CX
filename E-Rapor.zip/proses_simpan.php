<?php
include 'koneksi.php';

if (isset($_POST['id'])) {
    $key = $_POST['key_mapel'];
    
    // Jika kiriman dari AJAX (Auto-save mengirim satu ID saja)
    if (isset($_POST['autosave'])) {
        $id   = $_POST['id'];
        $uh1  = $_POST['uh1'];
        $uh2  = $_POST['uh2'];
        $psts = $_POST['psts'];
        $s    = $_POST['s'];
        $i    = $_POST['i'];
        $a    = $_POST['a'];

        $sql = "UPDATE nilaisiswa SET 
                uh1_$key = '$uh1', uh2_$key = '$uh2', psts_$key = '$psts',
                sakit = '$s', izin = '$i', alfa = '$a' 
                WHERE id = '$id'";
        mysqli_query($koneksi, $sql);
        echo "success";
        exit;
    }

    // Jika simpan manual (Tombol Simpan mengirim array)
    foreach ($_POST['id'] as $index => $id) {
        $uh1  = $_POST['uh1'][$index];
        $uh2  = $_POST['uh2'][$index];
        $psts = $_POST['psts'][$index];
        $s    = $_POST['s'][$index];
        $i    = $_POST['i'][$index];
        $a    = $_POST['a'][$index];

        $sql = "UPDATE nilaisiswa SET 
                uh1_$key = '$uh1', uh2_$key = '$uh2', psts_$key = '$psts',
                sakit = '$s', izin = '$i', alfa = '$a' 
                WHERE id = '$id'";
        mysqli_query($koneksi, $sql);
    }
    header("Location: " . $_SERVER['HTTP_REFERER'] . "&status=sukses");
}