<?php
session_start();
include 'koneksi.php';

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($koneksi, trim($_POST['username']));
    $password = trim($_POST['password']);

    // 1. Cek Tabel Admin (Mencoba teks biasa ATAU MD5)
    $query_admin = "SELECT * FROM admin WHERE username = '$username' AND (password = '$password' OR password = MD5('$password'))";
    $result_admin = mysqli_query($koneksi, $query_admin);

    if (mysqli_num_rows($result_admin) === 1) {
        $row = mysqli_fetch_assoc($result_admin);
        $_SESSION['login'] = true;
        $_SESSION['nama'] = $row['nama_lengkap'];
        $_SESSION['role'] = 'admin';
        header("Location: dashboard_admin.php");
        exit;
    }

    // 2. Cek Tabel Guru (Jika bukan admin)
    $query_guru = "SELECT * FROM guru WHERE nip = '$username' OR username = '$username'";
    $result_guru = mysqli_query($koneksi, $query_guru);

    if (mysqli_num_rows($result_guru) === 1) {
        $row = mysqli_fetch_assoc($result_guru);
        // Cek password (di data Anda guru menggunakan password 'guru123' atau NIP)
        if ($password == $row['password'] || $password == $row['nip']) { 
            $_SESSION['login'] = true;
            $_SESSION['nip'] = $row['nip'];
            $_SESSION['nama_guru'] = $row['nama_guru'];
            $_SESSION['role'] = 'guru';
            header("Location: dashboard_guru.php");
            exit;
        }
    }
    $error_msg = "Username atau Password salah!";
}
?>