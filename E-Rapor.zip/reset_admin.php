<?php
include 'koneksi.php';

// Password baru yang Anda inginkan
$password_baru = 'admin123'; 
$hash_baru = password_hash($password_baru, PASSWORD_DEFAULT);

// Update password admin di tabel guru
$query = "UPDATE guru SET password = '$hash_baru' WHERE username = 'admin'";

if (mysqli_query($koneksi, $query)) {
    echo "Password Admin berhasil diubah menjadi: <b>admin123</b><br>";
    echo "Silahkan hapus file ini dan coba login di login_admin.php";
} else {
    echo "Gagal update: " . mysqli_error($koneksi);
}
?>