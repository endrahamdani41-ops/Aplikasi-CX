// Ambil data dari form
$username  = $_POST['username']; 
$nama_guru = $_POST['nama_guru']; // Sesuaikan dengan atribut 'name' di form
$kelas     = $_POST['kelas'];     // Sesuaikan dengan atribut 'name' di form
$password  = password_hash($_POST['password'], PASSWORD_DEFAULT); // Enkripsi password

// Query INSERT yang benar sesuai struktur database Anda
$query = "INSERT INTO guru (username, password, nama_guru, kelas_ampu) 
          VALUES ('$username', '$password', '$nama_guru', '$kelas')";

mysqli_query($koneksi, $query);