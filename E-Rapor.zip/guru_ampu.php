<?php
session_start();
include 'koneksi.php';

// Tambah Data
if (isset($_POST['tambah'])) {
    $nama = mysqli_real_escape_string($koneksi, $_POST['nama_guru']);
    $kelas = mysqli_real_escape_string($koneksi, $_POST['kelas']);
    $mapel = mysqli_real_escape_string($koneksi, $_POST['mapel']);

    $query = "INSERT INTO guru_ampu (nama_guru, kelas, mapel) VALUES ('$nama', '$kelas', '$mapel')";
    mysqli_query($koneksi, $query);
    header("Location: guru_ampu.php?status=berhasil");
}

// Hapus Data
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($koneksi, "DELETE FROM guru_ampu WHERE id='$id'");
    header("Location: guru_ampu.php?status=terhapus");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manajemen Guru Ampu</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background: #000; color: #fff; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; }
        .card { background: #111; padding: 20px; border-radius: 12px; border: 1px solid #333; margin-bottom: 20px; }
        h2 { color: #8e44ad; margin-top: 0; }
        
        /* Form Styling */
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; color: #aaa; font-size: 0.9rem; }
        input, select { width: 100%; padding: 10px; background: #1a1a1a; border: 1px solid #444; color: #fff; border-radius: 6px; }
        .btn-tambah { background: #8e44ad; color: #fff; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: bold; width: 100%; }
        
        /* Table Styling */
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { background: #222; text-align: left; padding: 12px; color: #8e44ad; border-bottom: 2px solid #333; }
        td { padding: 12px; border-bottom: 1px solid #222; }
        .btn-hapus { color: #e74c3c; text-decoration: none; font-size: 0.9rem; }
        .btn-hapus:hover { text-decoration: underline; }
        .btn-back { display: inline-block; margin-bottom: 20px; color: #aaa; text-decoration: none; }
    </style>
</head>
<body>

<div class="container">
    <a href="dashboard_guru.php" class="btn-back"><i class="fas fa-arrow-left"></i> Kembali ke Dashboard</a>

    <div class="card">
        <h2><i class="fas fa-user-plus"></i> Tambah Pembagian Kelas</h2>
        <form action="" method="POST">
            <div class="form-group">
                <label>Nama Guru (Sesuai Database Login)</label>
                <input type="text" name="nama_guru" placeholder="Contoh: Hendra triyanto" required>
            </div>
            <div style="display: flex; gap: 15px;">
                <div class="form-group" style="flex: 1;">
                    <label>Kelas</label>
                    <input type="text" name="kelas" placeholder="Contoh: 8A" required>
                </div>
                <div class="form-group" style="flex: 1;">
                    <label>Mata Pelajaran</label>
                    <select name="mapel">
                        <option value="Informatika">Informatika</option>
                        <option value="PAI">PAI</option>
                        <option value="Matematika">Matematika</option>
                    </select>
                </div>
            </div>
            <button type="submit" name="tambah" class="btn-tambah">SIMPAN DATA</button>
        </form>
    </div>

    <div class="card">
        <h2><i class="fas fa-list"></i> Daftar Pembagian Kelas</h2>
        <table>
            <thead>
                <tr>
                    <th>GURU</th>
                    <th>KELAS</th>
                    <th>MAPEL</th>
                    <th>AKSI</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $res = mysqli_query($koneksi, "SELECT * FROM guru_ampu ORDER BY nama_guru ASC, kelas ASC");
                if (mysqli_num_rows($res) > 0) {
                    while($row = mysqli_fetch_array($res)) {
                        echo "<tr>
                                <td>".strtoupper($row['nama_guru'])."</td>
                                <td>".$row['kelas']."</td>
                                <td>".$row['mapel']."</td>
                                <td><a href='?hapus=".$row['id']."' class='btn-hapus' onclick='return confirm(\"Hapus tugas ini?\")'><i class='fas fa-trash'></i></a></td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='4' style='text-align:center; color:#555;'>Belum ada data.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>