<?php
include 'koneksi.php';

if(isset($_GET['id'])){
    $id = $_GET['id'];

    // 1. Hapus riwayat transaksi barang ini dulu (agar tidak error constraint)
    $hapus_riwayat = mysqli_query($conn, "DELETE FROM riwayat_stok WHERE id_barang = '$id'");

    if($hapus_riwayat){
        // 2. Baru hapus data barangnya
        $hapus_barang = mysqli_query($conn, "DELETE FROM barang WHERE id_barang = '$id'");
        
        if($hapus_barang){
            echo "<script>alert('Barang Berhasil Dihapus'); window.location='index.php';</script>";
        } else {
            echo "<script>alert('Gagal menghapus barang'); window.location='index.php';</script>";
        }
    }
}
?>