<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['login'])) {
    header("Location: login_guru.php");
    exit;
}

$username = $_SESSION['username'];

// Ambil data terbaru dari tabel guru
$query = mysqli_query($koneksi, "SELECT * FROM guru WHERE username = '$username'");
$data = mysqli_fetch_assoc($query);

// Variabel data untuk ditampilkan
$nama_guru  = $data['nama_guru'] ?? 'Nama Belum Diisi';
$nip_guru   = !empty($data['nip']) ? $data['nip'] : "Belum Diisi";
$mapel      = !empty($data['mapel']) ? $data['mapel'] : "-";
$wali_kelas = !empty($data['wali_kelas']) ? $data['wali_kelas'] : "Bukan Wali Kelas";
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Saya - E-Rapor</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { 
            font-family: 'Segoe UI', sans-serif; 
            background-color: #0f172a; 
            color: #f8fafc;
            display: flex; 
            justify-content: center; 
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        .card { 
            background: #1e293b; 
            width: 100%;
            max-width: 420px; 
            border-radius: 24px; 
            box-shadow: 0 20px 50px rgba(0,0,0,0.5); 
            overflow: hidden; 
            border: 1px solid #334155;
        }

        .header { 
            background: linear-gradient(135deg, #1e40af, #3b82f6); 
            color: white; 
            padding: 40px 20px; 
            text-align: center;
        }

        .header i {
            background: rgba(255, 255, 255, 0.2);
            padding: 20px;
            border-radius: 50%;
            margin-bottom: 15px;
            backdrop-filter: blur(5px);
        }

        .header h2 { margin: 10px 0 5px; font-size: 22px; letter-spacing: 1px; text-transform: uppercase; }
        .header p { margin: 0; opacity: 0.8; font-size: 14px; font-weight: 300; }

        .content { padding: 30px; }

        .item { 
            display: flex; 
            align-items: center; 
            margin-bottom: 15px; 
            background: #334155; 
            padding: 15px;
            border-radius: 16px;
            transition: 0.3s ease;
        }

        .item:hover {
            background: #3f4e66;
            transform: translateX(5px);
        }

        .item i { 
            width: 40px; 
            color: #60a5fa; 
            font-size: 20px; 
        }

        .text-group {
            display: flex;
            flex-direction: column;
        }

        .label { 
            font-size: 10px; 
            color: #94a3b8; 
            font-weight: bold; 
            text-transform: uppercase; 
            letter-spacing: 1px;
            margin-bottom: 2px;
        }

        .value { 
            font-size: 15px; 
            color: #f1f5f9; 
            font-weight: 500; 
        }

        .footer { 
            padding: 0 30px 30px; 
            display: flex; 
            gap: 12px; 
        }

        .btn { 
            flex: 1; 
            padding: 14px; 
            border-radius: 12px; 
            text-decoration: none; 
            text-align: center; 
            font-size: 14px; 
            font-weight: bold; 
            transition: 0.3s;
        }

        .btn-edit { background: #3b82f6; color: white; border: none; }
        .btn-edit:hover { background: #2563eb; transform: translateY(-2px); box-shadow: 0 5px 15px rgba(59,130,246,0.4); }

        .btn-back { background: #475569; color: #cbd5e1; }
        .btn-back:hover { background: #64748b; color: white; }
    </style>
</head>
<body>

    <div class="card">
        <div class="header">
            <i class="fas fa-user-tie fa-3x"></i>
            <h2>Profil Guru</h2>
            <p>Wali Kelas: <strong><?= $wali_kelas ?></strong></p>
        </div>

        <div class="content">
            <div class="item">
                <i class="fas fa-signature"></i>
                <div class="text-group">
                    <span class="label">Nama Lengkap</span>
                    <span class="value"><?= $nama_guru ?></span>
                </div>
            </div>

            <div class="item">
                <i class="fas fa-id-card"></i>
                <div class="text-group">
                    <span class="label">NIP</span>
                    <span class="value"><?= $nip_guru ?></span>
                </div>
            </div>

            <div class="item">
                <i class="fas fa-book"></i>
                <div class="text-group">
                    <span class="label">Mata Pelajaran</span>
                    <span class="value"><?= $mapel ?></span>
                </div>
            </div>

            <div class="item">
                <i class="fas fa-key"></i>
                <div class="text-group">
                    <span class="label">Username Sistem</span>
                    <span class="value"><?= $username ?></span>
                </div>
            </div>
        </div>

        <div class="footer">
            <a href="dashboard_guru.php" class="btn btn-back">KEMBALI</a>
            <a href="edit_profil.php" class="btn btn-edit"><i class="fas fa-edit"></i> EDIT PROFIL</a>
        </div>
    </div>

</body>
</html>