<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'koneksi.php';

// 1. PROTEKSI HALAMAN
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'guru') {
    header("Location: index.php");
    exit;
}

// 2. AMBIL DATA DARI SESSION
$nama_guru  = $_SESSION['nama']; 
$mapel_guru = $_SESSION['mapel'];
$kelas_wali = $_SESSION['wali_kelas']; 

// 3. LOGIKA HALAMAN DINAMIS
$page = isset($_GET['page']) ? $_GET['page'] : 'home';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Guru | E-Rapor Digital</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap');
        
        body { background-color: #050505; color: white; font-family: 'Plus Jakarta Sans', sans-serif; scroll-behavior: smooth; overflow-x: hidden; }
        .sidebar { background-color: #0a0a0a; border-right: 1px solid #1a1a1a; }
        
        /* Glassmorphism Card Style */
        .card-premium { 
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.03) 0%, rgba(255, 255, 255, 0.01) 100%);
            border: 1px solid rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border-radius: 28px;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .card-premium:hover { 
            border-color: #9333ea; 
            transform: translateY(-8px);
            background: rgba(147, 51, 234, 0.03);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
        }

        /* Menu Active Glow */
        .menu-active { 
            background: linear-gradient(90deg, rgba(147, 51, 234, 0.15) 0%, transparent 100%); 
            color: #a855f7; 
            border-left: 3px solid #a855f7;
            font-weight: 800;
        }

        .text-glow {
            background: linear-gradient(to bottom, #fff 20%, #a855f7 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        /* Back Button Style */
        .btn-back {
            display: flex; align-items: center; justify-content: center;
            width: 48px; height: 48px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 16px; color: #94a3b8;
            transition: all 0.3s ease;
        }
        .btn-back:hover {
            background: rgba(168, 85, 247, 0.2);
            color: #a855f7; border-color: rgba(168, 85, 247, 0.5);
            transform: translateX(-5px);
        }
    </style>
</head>
<body class="flex min-h-screen">

    <div class="sidebar w-72 flex flex-col fixed h-full z-50">
        <div class="p-8">
            <h1 class="text-purple-500 font-black text-2xl italic tracking-tighter uppercase">E-RAPOR</h1>
            <p class="text-[9px] text-gray-500 tracking-[0.3em] font-bold mt-1 uppercase">SMPN 110 JAKARTA</p>
        </div>

        <nav class="flex-1 px-4 space-y-1">
            <p class="px-4 text-[10px] font-bold text-gray-600 uppercase tracking-widest mb-3 mt-4">Utama</p>
            <a href="dashboard_guru.php?page=home" class="flex items-center gap-3 p-3 rounded-r-xl <?= ($page == 'home') ? 'menu-active' : 'text-gray-500 hover:text-white transition' ?>">
                <i class="fas fa-th-large w-5 text-center"></i> Dashboard
            </a>
            
            <a href="dashboard_guru.php?page=input_nilai" class="flex items-center gap-3 p-3 rounded-r-xl <?= ($page == 'input_nilai') ? 'menu-active' : 'text-gray-500 hover:text-white transition' ?>">
                <i class="fas fa-edit w-5 text-center"></i> Input Nilai
            </a>

            <?php if (!empty($kelas_wali) && $kelas_wali != '-') : ?><br>
                <p class="px-4 text-[10px] font-bold text-gray-600 uppercase tracking-widest mb-3 mt-8">Wali Kelas (<?= $kelas_wali ?>)</p>
                <a href="data_siswa_wali.php" class="flex items-center gap-3 p-3 text-gray-500 hover:text-white rounded-xl transition">
                    <i class="fas fa-users w-5 text-center"></i> Data Siswa Wali
                </a>
                <a href="absensi.php" class="flex items-center gap-3 p-3 text-gray-500 hover:text-white rounded-xl transition">
                    <i class="fas fa-calendar-check w-5 text-center"></i> Absensi
                </a>            
                <a href="ledger_nilai.php" class="flex items-center gap-3 p-3 text-gray-500 hover:text-white rounded-xl transition">
                    <i class="fas fa-book-open w-5 text-center text-purple-400"></i> Ledger Nilai
                </a>
            	<a href="cetak_rapor.php" class="flex items-center gap-3 p-3 text-gray-500 hover:text-white rounded-xl transition">
                    <i class="fas fa-print w-5 text-center"></i> Cetak Rapor
                </a>
            <?php endif; ?><br>

            <p class="px-4 text-[10px] font-bold text-gray-600 uppercase tracking-widest mb-3 mt-8">Sistem</p>
            <a href="profil.php" class="flex items-center gap-3 p-3 text-gray-500 hover:text-white rounded-xl transition">
                <i class="fas fa-user-circle w-5 text-center"></i> Profil Saya
            </a>
        </nav>

        <div class="p-6">
            <a href="logout.php" onclick="return confirm('Keluar dari sistem?')" class="flex items-center justify-center gap-2 p-3 text-red-500 bg-red-500/5 border border-red-500/10 rounded-2xl font-black text-[10px] tracking-widest uppercase italic hover:bg-red-500 hover:text-white transition-all">
                <i class="fas fa-sign-out-alt"></i> KELUAR
            </a>
        </div>
    </div>

    <div class="ml-72 flex-1 p-10">
        
        <header class="flex justify-between items-center mb-12">
            <div class="flex items-center gap-6">
                <?php if ($page != 'home'): ?>
                    <a href="dashboard_guru.php?page=home" class="btn-back">
                        <i class="fas fa-arrow-left"></i>
                    </a>
                <?php endif; ?>
                <div>
                    <h2 class="text-4xl font-black italic uppercase tracking-tighter leading-none">
                        <?php 
                            if($page == 'input_nilai') echo 'PILIH <span class="text-purple-500">ROMBEL</span>';
                            else echo 'PANEL <span class="text-purple-500">KENDALI</span>';
                        ?>
                    </h2>
                    <p class="text-gray-500 font-medium mt-1">
                        <?php 
                            if($page == 'input_nilai') echo 'Pilih kelas mengajar untuk melakukan input nilai.';
                            else echo 'Selamat datang kembali, '.explode(' ', trim($nama_guru))[0].'.';
                        ?>
                    </p>
                </div>
            </div>
            <div class="flex items-center gap-4 bg-[#0a0a0a] p-2 pr-6 rounded-3xl border border-white/5 shadow-2xl">
                <div class="w-12 h-12 bg-gradient-to-br from-purple-600 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg font-black italic text-xl">
                    <?= substr($nama_guru, 0, 1) ?>
                </div>
                <div class="text-left">
                    <p class="text-xs font-black uppercase text-white tracking-tight"><?= $nama_guru ?></p>
                    <p class="text-[9px] text-purple-500 font-bold uppercase tracking-widest italic"><?= $mapel_guru ?></p>
                </div>
            </div>
        </header>

        <?php if ($page == 'home') : ?>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
                <div class="card-premium p-8 border-l-4 border-l-purple-600">
                    <p class="text-gray-500 text-[10px] uppercase font-black tracking-widest mb-2">Mata Pelajaran</p>
                    <h3 class="text-2xl font-black italic uppercase"><?= $mapel_guru ?></h3>
                </div>
                <div class="card-premium p-8 border-l-4 border-l-green-500">
                    <p class="text-gray-500 text-[10px] uppercase font-black tracking-widest mb-2">Status Wali</p>
                    <h3 class="text-2xl font-black italic uppercase text-green-400">
                        <?= (!empty($kelas_wali) && $kelas_wali != '-') ? "KELAS " . $kelas_wali : "GURU MAPEL"; ?>
                    </h3>
                </div>
                <div class="card-premium p-8 border-l-4 border-l-blue-500">
                    <p class="text-gray-500 text-[10px] uppercase font-black tracking-widest mb-2">Tahun Ajaran</p>
                    <h3 class="text-2xl font-black italic uppercase text-blue-400">2025/2026</h3>
                </div>
            </div>

            <div class="card-premium p-12 bg-gradient-to-br from-purple-900/10 to-transparent">
                <h3 class="text-2xl font-black italic uppercase mb-4 text-purple-400 tracking-tighter">Petunjuk Sistem</h3>
                <p class="text-gray-400 text-sm leading-relaxed max-w-3xl font-medium">
                    Gunakan menu <span class="text-white italic">Input Nilai</span> untuk mengisi capaian siswa. Jika Anda wali kelas, fitur <span class="text-white italic">Ledger</span> dan <span class="text-white italic">Cetak Rapor</span> tersedia di kategori Wali Kelas.
                </p>
            </div>

        <?php elseif ($page == 'input_nilai') : ?>
            <div class="animate-in fade-in slide-in-from-bottom-5 duration-700">
                <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
                    <?php 
                    $q_ampu = mysqli_query($koneksi, "SELECT kelas FROM guru_ampu WHERE nama_guru = '$nama_guru' ORDER BY kelas ASC");
                    if(mysqli_num_rows($q_ampu) > 0) :
                        while($da = mysqli_fetch_assoc($q_ampu)) : ?>
                            <a href="proses_input_nilai.php?kelas=<?= $da['kelas'] ?>" class="card-premium p-10 flex flex-col items-center group">
                                <div class="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center mb-6 border border-white/10 group-hover:border-purple-500/50 group-hover:bg-purple-500/20 transition-all">
                                    <i class="fas fa-layer-group text-gray-500 group-hover:text-purple-400"></i>
                                </div>
                                <p class="text-[10px] text-gray-600 font-black uppercase tracking-[0.3em] mb-1">Kelas</p>
                                <h4 class="text-5xl font-black italic tracking-tighter text-glow group-hover:scale-110 transition-all duration-500">
                                    <?= $da['kelas'] ?>
                                </h4>
                                <div class="mt-8 flex items-center gap-2 text-[9px] font-black uppercase tracking-widest text-gray-600 group-hover:text-purple-400 transition-colors">
                                    <span>MULAI INPUT</span>
                                    <i class="fas fa-arrow-right text-[8px]"></i>
                                </div>
                            </a>
                        <?php endwhile; 
                    else : ?>
                        <div class="col-span-full py-20 text-center card-premium border-dashed">
                            <i class="fas fa-folder-open text-gray-800 text-4xl mb-4"></i>
                            <p class="text-gray-600 font-bold italic uppercase tracking-widest">Tidak ada data kelas ditemukan.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

    </div>
</body>
</html>