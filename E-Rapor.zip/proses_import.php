<?php
session_start();
include 'koneksi.php';

if (isset($_POST['import'])) {
    $file_tmp  = $_FILES['file_excel']['tmp_name'];
    $key_mapel = strtolower(trim($_POST['key_mapel'])); // Pastikan isinya 'inf'
    $kelas     = $_POST['kelas'];

    if (($handle = fopen($file_tmp, "r")) !== FALSE) {
        $berhasil = 0;
        $baris_csv = 0;

        // 1. Deteksi otomatis pemisah (koma atau titik koma)
        $first_line = fgets($handle);
        $delimiter = (substr_count($first_line, ';') > substr_count($first_line, ',')) ? ';' : ',';
        rewind($handle);

        while (($data = fgetcsv($handle, 1000, $delimiter)) !== FALSE) {
            $baris_csv++;
            if ($baris_csv <= 2) continue; // Lewati judul dan header

            // 2. Ambil Nama & Bersihkan (Ubah ke KAPITAL agar pas dengan database Anda)
            $nama_raw = isset($data[1]) ? trim($data[1]) : '';
            if (empty($nama_raw)) continue;
            
            $nama_bersih = strtoupper($nama_raw);

            // 3. Ambil Nilai dari kolom C, D, E, F, G, H
            $ph1  = isset($data[2]) ? (int)$data[2] : 0;
            $ph2  = isset($data[3]) ? (int)$data[3] : 0;
            $psts = isset($data[4]) ? (int)$data[4] : 0;
            $s    = isset($data[5]) ? (int)$data[5] : 0;
            $i_   = isset($data[6]) ? (int)$data[6] : 0;
            $a    = isset($data[7]) ? (int)$data[7] : 0;

            // 4. Query UPDATE dengan pencocokan ekstra ketat
            // Kita pakai TRIM dan UPPER di SQL juga untuk jaga-jaga
            $sql = "UPDATE nilaisiswa SET 
                    uh1_$key_mapel = $ph1, 
                    uh2_$key_mapel = $ph2, 
                    psts_$key_mapel = $psts,
                    sakit = $s, 
                    izin = $i_, 
                    alfa = $a 
                    WHERE UPPER(TRIM(nama)) = '$nama_bersih' 
                    AND kelas = '$kelas'";
            
            if (mysqli_query($koneksi, $sql)) {
                // affected_rows akan > 0 jika data berubah, 
                // atau 0 jika data yang diupload SAMA dengan data lama.
                // Kita hitung sebagai 'berhasil diproses' jika tidak error.
                $berhasil++;
            }
        }
        fclose($handle);

        echo "<script>
                alert('SELESAI!\\nTotal data di CSV: " . ($baris_csv - 2) . "\\nData Berhasil Disinkronkan: $berhasil');
                window.location.href='input_nilai.php?kelas=$kelas';
              </script>";
    } else {
        echo "Gagal membuka file.";
    }
}