<?php
session_start();
if (!isset($_SESSION['login'])) { header("Location: login.php"); exit; }

include 'koneksi.php';

// Nama file backup
$filename = "backup_stok_" . date('Y-m-d') . ".sql";

header('Content-Type: application/octet-stream');
header("Content-Transfer-Encoding: Binary");
header("Content-disposition: attachment; filename=\"" . $filename . "\"");

// Mengambil semua tabel (barang, riwayat_stok, users)
$tables = array("barang", "riwayat_stok", "users");
foreach ($tables as $table) {
    $result = mysqli_query($conn, "SELECT * FROM $table");
    $num_fields = mysqli_num_fields($result);

    echo "DROP TABLE IF EXISTS $table;\n";
    $row2 = mysqli_fetch_row(mysqli_query($conn, "SHOW CREATE TABLE $table"));
    echo $row2[1] . ";\n\n";

    for ($i = 0; $i < $num_fields; $i++) {
        while ($row = mysqli_fetch_row($result)) {
            echo "INSERT INTO $table VALUES(";
            for ($j = 0; $j < $num_fields; $j++) {
                $row[$j] = addslashes($row[$j]);
                if (isset($row[$j])) { echo '"' . $row[$j] . '"'; } else { echo '""'; }
                if ($j < ($num_fields - 1)) { echo ','; }
            }
            echo ");\n";
        }
    }
    echo "\n\n\n";
}
exit;
?>