<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['login'])) {
    header("Location: login_guru.php");
    exit;
}

$kelas_ampu = $_SESSION['kelas'];
// Pastikan query mengambil semua kolom yang diperlukan termasuk absensi dan nama ortu
$query_siswa = mysqli_query($koneksi, "SELECT * FROM nilaisiswa WHERE kelas = '$kelas_ampu' ORDER BY nama ASC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cetak Semua Rapor - Kelas <?php echo $kelas_ampu; ?></title>
    <style>
        body { font-family: 'Arial', sans-serif; font-size: 12px; margin: 0; padding: 0; background-color: #f0f0f0; }
        
        .halaman-rapor {
            width: 210mm;
            min-height: 297mm;
            padding: 15mm 20mm;
            margin: 10mm auto;
            background: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            page-break-after: always; /* Membuat setiap siswa jadi satu halaman */
            box-sizing: border-box;
        }

        .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 20px; }
        .tabel-info { width: 100%; margin-bottom: 15px; }
        .tabel-info td { padding: 3px 0; }

        .tabel-nilai { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        .tabel-nilai th, .tabel-nilai td { border: 1px solid #000; padding: 8px; text-align: center; }
        .tabel-nilai th { background-color: #f2f2f2; }
        
        .tabel-absensi { width: 40%; border-collapse: collapse; margin-top: 10px; }
        .tabel-absensi td { border: 1px solid #000; padding: 6px; }

        .footer-ttd { margin-top: 40px; width: 100%; display: flex; justify-content: space-between; }
        .kolom-ttd { width: 200px; text-align: center; }

        @media print {
            .no-print { display: none; }
            .halaman-rapor { margin: 0; border: none; box-shadow: none; width: 100%; padding: 10mm; }
            body { background: none; }
        }
    </style>
</head>
<body>

<div class="no-print" style="position: fixed; top: 10px; right: 10px; z-index: 999;">
    <button onclick="window.print()" style="background: #27ae60; color: white; padding: 10px 20px; border: none; cursor: pointer; border-radius: 5px;">
        <b>CETAK SEMUA (PDF)</b>
    </button>
    <a href="dashboard_guru.php" style="background: #e74c3c; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-left: 5px;">KEMBALI</a>
</div>

<?php while ($s = mysqli_fetch_array($query_siswa)) : ?>
<div class="halaman-rapor">
    <div class="header">
        <h2 style="margin:0;">LAPORAN HASIL BELAJAR (RAPOR)</h2>
        <p style="margin:5px 0;">SMP NEGERI 110 JAKARTA</p>
    </div>

    <table class="tabel-info">
        <tr>
            <td width="15%">Nama Pelajar</td><td>:</td><td width="35%"><b><?php echo strtoupper($s['nama']); ?></b></td>
            <td width="15%">Kelas</td><td>:</td><td><?php echo $s['kelas']; ?></td>
        </tr>
        <tr>
            <td>NIS</td><td>:</td><td><?php echo $s['nis']; ?></td>
            <td>Semester</td><td>:</td><td>Ganjil</td>
        </tr>
    </table>

    <table class="tabel-nilai">
        <thead>
            <tr>
                <th width="5%">NO</th>
                <th width="35%">MATA PELAJARAN</th>
                <th width="10%">KKM</th>
                <th width="10%">PH 1</th>
                <th width="10%">PH 2</th>
                <th width="10%">PSTS</th>
                <th width="20%">PREDIKAT</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $mapels = [
                'Pendidikan Agama Islam' => 'pai', 'Pendidikan Pancasila' => 'pp',
                'Bahasa Indonesia' => 'bind', 'Matematika' => 'mtk',
                'IPA' => 'ipa', 'IPS' => 'ips', 'Bahasa Inggris' => 'bing',
                'PJOK' => 'pjok', 'Informatika' => 'inf', 'Seni Budaya' => 'sbk'
            ];
            $no = 1;
            foreach ($mapels as $label => $key) {
                $ph1 = $s['uh1_'.$key];
                $ph2 = $s['uh2_'.$key];
                $psts = $s['psts_'.$key];
                $rata = round(($ph1 + $ph2 + $psts) / 3);
                
                // Logika Predikat
                if ($rata >= 90) $pred = "Sangat Baik";
                elseif ($rata >= 82) $pred = "Baik";
                elseif ($rata >= 70) $pred = "Cukup";
                else $pred = "Perlu Bimbingan";

                echo "<tr>
                        <td>$no</td>
                        <td style='text-align:left;'>$label</td>
                        <td>82</td>
                        <td>$ph1</td>
                        <td>$ph2</td>
                        <td>$psts</td>
                        <td>$pred</td>
                      </tr>";
                $no++;
            }
            ?>
        </tbody>
    </table>

    <b>Ketidakhadiran</b>
    <table class="tabel-absensi">
        <tr><td width="60%">Sakit</td><td><?php echo ($s['sakit'] ?? 0); ?> hari</td></tr>
        <tr><td>Izin</td><td><?php echo ($s['izin'] ?? 0); ?> hari</td></tr>
        <tr><td>Tanpa Keterangan</td><td><?php echo ($s['alfa'] ?? 0); ?> hari</td></tr>
    </table>

    <div class="footer-ttd">
        <div class="kolom-ttd">
            <p>Mengetahui,<br>Orang Tua/Wali,</p>
            <br><br><br>
            <p><b>( <?php echo !empty($s['nama_ortu']) ? $s['nama_ortu'] : '..........................'; ?> )</b></p>
        </div>
        <div class="kolom-ttd">
            <p>Jakarta, <?php echo date('d F Y'); ?><br>Wali Kelas,</p>
            <br><br><br>
            <p><b>( <?php echo $_SESSION['nama']; ?> )</b></p>
        </div>
    </div>
</div>
<?php endwhile; ?>

</body>
</html>