<?php
session_start();
include 'koneksi.php';

// Pastikan yang akses adalah siswa yang sudah login
if (!isset($_SESSION['login_siswa'])) {
    header("Location: login_siswa.php");
    exit;
}

$nis = $_SESSION['nis'];
$pesan = "";
$tipe_pesan = "";

if (isset($_POST['update_pw'])) {
    $pw_baru = mysqli_real_escape_string($koneksi, $_POST['pw_baru']);
    $konfirmasi_pw = mysqli_real_escape_string($koneksi, $_POST['konfirmasi_pw']);

    if ($pw_baru === $konfirmasi_pw) {
        // Jika Anda menggunakan MD5 di login_siswa.php, gunakan: md5($pw_baru)
        // Jika plain text, biarkan langsung $pw_baru
        $update = mysqli_query($koneksi, "UPDATE nilaisiswa SET password = '$pw_baru' WHERE nis = '$nis'");

        if ($update) {
            $pesan = "Password berhasil diperbarui!";
            $tipe_pesan = "success";
        } else {
            $pesan = "Gagal memperbarui database.";
            $tipe_pesan = "danger";
        }
    } else {
        $pesan = "Konfirmasi password tidak cocok!";
        $tipe_pesan = "danger";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ganti Password Siswa</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --bg-dark: #121212;
            --bg-card: #1e1e1e;
            --primary-purple: #8e44ad;
            --text-main: #e0e0e0;
            --border-color: #333;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: var(--bg-dark);
            color: var(--text-main);
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .card {
            width: 100%;
            max-width: 400px;
            background: var(--bg-card);
            padding: 30px;
            border-radius: 15px;
            border: 1px solid var(--border-color);
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
        }

        h2 { text-align: center; color: var(--primary-purple); margin-bottom: 25px; }

        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; font-size: 0.9rem; color: #bbb; }
        
        input {
            width: 100%;
            padding: 12px;
            background: #252525;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            color: white;
            box-sizing: border-box;
            outline: none;
        }

        input:focus { border-color: var(--primary-purple); }

        .btn-update {
            width: 100%;
            padding: 12px;
            background: var(--primary-purple);
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn-update:hover { background: #9b59b6; }

        .alert {
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            font-size: 0.9rem;
        }
        .success { background: rgba(46, 204, 113, 0.2); color: #2ecc71; border: 1px solid #2ecc71; }
        .danger { background: rgba(231, 76, 60, 0.2); color: #e74c3c; border: 1px solid #e74c3c; }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #888;
            text-decoration: none;
            font-size: 0.9rem;
        }
        .back-link:hover { color: var(--primary-purple); }
    </style>
</head>
<body>

<div class="card">
    <h2><i class="fas fa-key"></i> Ganti Password</h2>

    <?php if ($pesan !== ""): ?>
        <div class="alert <?php echo $tipe_pesan; ?>">
            <?php echo $pesan; ?>
        </div>
    <?php endif; ?>

    <form action="" method="POST">
        <div class="form-group">
            <label>Password Baru</label>
            <input type="password" name="pw_baru" placeholder="Masukkan password baru" required>
        </div>
        <div class="form-group">
            <label>Konfirmasi Password Baru</label>
            <input type="password" name="konfirmasi_pw" placeholder="Ulangi password baru" required>
        </div>
        <button type="submit" name="update_pw" class="btn-update">Simpan Perubahan</button>
    </form>

    <a href="dashboard_siswa.php" class="back-link"><i class="fas fa-arrow-left"></i> Kembali</a>
</div>

</body>
</html>