<?php 
session_start();
if (!isset($_SESSION['login'])) { header("Location: login.php"); exit; }
?>
<?php
include 'koneksi.php'; 

if(isset($_POST['submit'])){
    $nama = $_POST['nama_barang'];
    $stok = $_POST['stok_awal'];

    // Input data ke tabel barang
    $sql = "INSERT INTO barang (nama_barang, stok_awal) VALUES ('$nama', '$stok')";

    if(mysqli_query($conn, $sql)){
        echo "<script>alert('Barang Baru Berhasil Ditambahkan'); window.location='index.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Barang Baru</title>
</head>
<body>
    <h2>Registrasi Barang Baru</h2>
    <form method="POST">
        Nama Barang: <br>
        <input type="text" name="nama_barang" placeholder="Misal: Keyboard Mechanical" required><br><br>
        
        Stok Awal: <br>
        <input type="number" name="stok_awal" value="0" required><br><br>
        
        <button type="submit" name="submit">Simpan Barang</button>
        <a href="index.php">Batal</a>
    </form>
</body>
</html>