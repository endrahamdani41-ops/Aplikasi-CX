<?php
session_start();
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // 1. Ambil data utama dari form
    $mapel = mysqli_real_escape_string($koneksi, $_POST['mapel']);
    $kelas = mysqli_real_escape_string($koneksi, $_POST['kelas']);
    
    // 2. Ambil data array (kumpulan data siswa)
    $nis_array        = $_POST['nis'];
    $nama_murid_array = $_POST['nama_murid']; 
    $uh1_array        = $_POST['uh1'];
    $uh2_array        = $_POST['uh2'];
    $asts_array       = $_POST['asts'];

    $berhasil = 0;

    // 3. Looping untuk memproses setiap siswa satu per satu
    foreach ($nis_array as $index => $nis) {
        $nis        = mysqli_real_escape_string($koneksi, $nis);
        $nama_murid = mysqli_real_escape_string($koneksi, $nama_murid_array[$index]);
        $uh1        = mysqli_real_escape_string($koneksi, $uh1_array[$index]);
        $uh2        = mysqli_real_escape_string($koneksi, $uh2_array[$index]);
        $asts       = mysqli_real_escape_string($koneksi, $asts_array[$index]);

        /**
         * Menggunakan REPLACE INTO:
         * Jika kombinasi NIS + MAPEL sudah ada, data lama akan ditimpa (update).
         * Jika belum ada, data baru akan ditambahkan (insert).
         */
        $query = "REPLACE INTO nilai (nis, nama_murid, mapel, kelas, uh1, uh2, asts) 
                  VALUES ('$nis', '$nama_murid', '$mapel', '$kelas', '$uh1', '$uh2', '$asts')";
        
        if (mysqli_query($koneksi, $query)) {
            $berhasil++;
        }
    }

    // 4. Feedback ke user
    echo "<script>
            alert('Berhasil menyimpan $berhasil data nilai ke dalam sistem.');
            window.location.href = 'proses_input_nilai.php?kelas=$kelas';
          </script>";

} else {
    // Jika file diakses secara ilegal (tanpa submit)
    header("Location: input_nilai.php");
    exit;
}
?>