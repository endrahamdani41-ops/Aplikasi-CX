<?php
// Mencegah output liar agar file tidak corrupt
ob_start(); 
session_start();
include 'koneksi.php';

if (!isset($_SESSION['login'])) {
    header("Location: login_guru.php");
    exit;
}

// Ambil variabel dari session
$kelas_session = $_SESSION['kelas']; 
$mapel_guru    = $_SESSION['mapel'];

// Bersihkan buffer
if (ob_get_length()) ob_clean();

// Header Excel
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Blanko_Nilai_Kelas_$kelas_session.xls");
header("Pragma: no-cache");
header("Expires: 0");

/** * QUERY SQL:
 * Kami menggunakan TRIM() untuk menghapus spasi hantu
 * Kami menggunakan UPPER() agar '8f' atau '8F' tetap terbaca sama
 */
$query_siswa = mysqli_query($koneksi, "SELECT nis, nama FROM nilaisiswa 
                                      WHERE UPPER(TRIM(kelas)) = UPPER(TRIM('$kelas_session')) 
                                      ORDER BY nama ASC");
?>

<table border="1">
    <thead>
        <tr>
            <th bgcolor="#CCCCCC">NIS</th>
            <th bgcolor="#CCCCCC">NAMA SISWA</th>
            <th bgcolor="#00FFFF">PH 1 (<?php echo strtoupper($mapel_guru); ?>)</th>
            <th bgcolor="#00FFFF">PH 2 (<?php echo strtoupper($mapel_guru); ?>)</th>
            <th bgcolor="#00FFFF">PSTS (<?php echo strtoupper($mapel_guru); ?>)</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        if (mysqli_num_rows($query_siswa) > 0) {
            while($row = mysqli_fetch_assoc($query_siswa)) {
                echo "<tr>";
                echo "<td style='mso-number-format:\"\@\";'>" . $row['nis'] . "</td>"; // Format teks agar NIS tidak jadi angka berantakan
                echo "<td>" . strtoupper($row['nama']) . "</td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "</tr>";
            }
        } else {
            // Pesan jika database memang kosong untuk kelas tersebut
            echo "<tr><td colspan='5' align='center' style='color:red;'>Data siswa kelas $kelas_session tidak ditemukan di tabel nilaisiswa.</td></tr>";
        }
        ?>
    </tbody>
</table>

<?php
ob_end_flush();
exit;
?>