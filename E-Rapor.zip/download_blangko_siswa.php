<?php
$filename = "blangko_siswa_nis.csv";
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=' . $filename);

$output = fopen('php://output', 'w');

// Instruksi agar Excel langsung membagi kolom
fwrite($output, "sep=;\n"); 

// Header: NIS;Nama Murid;Kelas
fwrite($output, "NIS;Nama Murid;Kelas\n");

// Contoh Data (Gunakan NIS asli/sesuai format sekolah)
fwrite($output, "2024004;ALBIBIT DESWAN;8A\n");
fwrite($output, "2024005;ZAHWA ALIYA NAJYA;8B\n");

fclose($output);
exit;
?>