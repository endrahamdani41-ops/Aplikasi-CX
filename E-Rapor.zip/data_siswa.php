<?php
session_start();
include 'koneksi.php';

// --- 1. PROSES SIMPAN MANUAL ---
if (isset($_POST['simpan_manual'])) {
    $nis   = mysqli_real_escape_string($koneksi, trim($_POST['nis']));
    $nama  = mysqli_real_escape_string($koneksi, strtoupper(trim($_POST['nama'])));
    $kelas = mysqli_real_escape_string($koneksi, strtoupper(trim($_POST['kelas'])));
    
    if(!empty($nis) && !empty($nama)) {
        $cek = mysqli_query($koneksi, "SELECT nis FROM siswa WHERE nis = '$nis'");
        if(mysqli_num_rows($cek) > 0) {
            echo "<script>alert('Gagal: NIS $nis sudah terdaftar!'); window.location='data_siswa.php';</script>";
        } else {
            $query = "INSERT INTO siswa (nis, nama_murid, kelas) VALUES ('$nis', '$nama', '$kelas')";
            if (mysqli_query($koneksi, $query)) {
                echo "<script>alert('Siswa Berhasil Ditambahkan!'); window.location='data_siswa.php';</script>";
            }
        }
    }
}

// --- 2. PROSES UPLOAD CSV ---
if (isset($_POST['upload_csv'])) {
    $file_tmp = $_FILES['file_csv']['tmp_name'];
    if (is_uploaded_file($file_tmp)) {
        $handle = fopen($file_tmp, "r");
        $berhasil = 0;
        while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
            if (empty($data[0]) || strtolower($data[0]) == 'nis' || strpos($data[0], 'sep=') !== false) {
                continue;
            }
            $nis   = mysqli_real_escape_string($koneksi, trim($data[0]));
            $nama  = mysqli_real_escape_string($koneksi, strtoupper(trim($data[1])));
            $kelas = mysqli_real_escape_string($koneksi, strtoupper(trim($data[2])));

            $sql = "REPLACE INTO siswa (nis, nama_murid, kelas) VALUES ('$nis', '$nama', '$kelas')";
            if (mysqli_query($koneksi, $sql)) { $berhasil++; }
        }
        fclose($handle);
        echo "<script>alert('Selesai! $berhasil data siswa diproses.'); window.location='data_siswa.php';</script>";
    }
}

// --- 3. PROSES HAPUS ---
if (isset($_GET['hapus'])) {
    $nis_hapus = $_GET['hapus'];
    mysqli_query($koneksi, "DELETE FROM siswa WHERE nis='$nis_hapus'");
    header("Location: data_siswa.php");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Database Siswa | E-Rapor Digital</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background: #000; color: #fff; padding: 20px; }
        .container { max-width: 1100px; margin: 0 auto; }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; }
        .card { background: #111; border: 1px solid #333; padding: 20px; border-radius: 12px; }
        h2 { font-size: 1rem; color: #a855f7; margin-top: 0; margin-bottom: 15px; text-transform: uppercase; letter-spacing: 1px; }
        
        /* SEARCH BOX - DIPERKECIL */
        .search-box { position: relative; width: 220px; }
        .search-box input { 
            width: 100%; padding: 8px 10px 8px 35px; background: #1a1a1a; 
            border: 1px solid #333; color: #fff; border-radius: 8px; outline: none;
            font-size: 0.8rem; transition: 0.3s;
        }
        .search-box input:focus { border-color: #a855f7; background: #222; }
        .search-box i { position: absolute; left: 12px; top: 9px; color: #555; font-size: 0.85rem; }

        /* TABLE STYLING */
        .table-wrapper { max-height: 480px; overflow-y: auto; border: 1px solid #222; border-radius: 8px; }
        table { width: 100%; border-collapse: collapse; }
        thead th { position: sticky; top: 0; background: #18181b; z-index: 10; color: #a855f7; text-align: left; padding: 12px; font-size: 0.75rem; border-bottom: 2px solid #333; }
        td { padding: 10px 12px; border-bottom: 1px solid #18181b; font-size: 0.85rem; color: #ccc; }
        tr:hover td { background: #1a1a1a; }
        
        .badge { background: #2563eb; padding: 2px 8px; border-radius: 4px; font-size: 0.7rem; font-weight: bold; }
        .btn { width: 100%; padding: 12px; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; color: #fff; transition: 0.2s; }
        
        /* CUSTOM SCROLLBAR */
        .table-wrapper::-webkit-scrollbar { width: 5px; }
        .table-wrapper::-webkit-scrollbar-thumb { background: #333; border-radius: 10px; }
        .table-wrapper::-webkit-scrollbar-thumb:hover { background: #a855f7; }

        input[type="text"], input[type="file"] { width: 100%; padding: 10px; background: #000; border: 1px solid #333; color: #fff; border-radius: 6px; margin-bottom: 10px; box-sizing: border-box; font-size: 0.85rem; }
    </style>
</head>
<body>

<div class="container">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h1 style="font-size: 1.4rem; font-weight: 800;"><i class="fas fa-database text-purple-500"></i> DATA SISWA</h1>
        <a href="dashboard_admin.php" style="color: #666; text-decoration: none; font-size: 0.9rem;"><i class="fas fa-arrow-left"></i> Kembali</a>
    </div>

    <div class="grid">
        <div class="card">
            <h2><i class="fas fa-user-plus"></i> Tambah Manual</h2>
            <form action="" method="POST">
                <input type="text" name="nis" placeholder="Masukkan NIS" required>
                <input type="text" name="nama" placeholder="Nama Lengkap Siswa" required>
                <input type="text" name="kelas" placeholder="Kelas (Contoh: 8F)" required>
                <button type="submit" name="simpan_manual" class="btn" style="background:#8e44ad;">SIMPAN</button>
            </form>
        </div>

        <div class="card">
            <h2><i class="fas fa-cloud-upload-alt"></i> Import CSV</h2>
            <a href="download_blangko_siswa.php" style="display:block; text-align:center; color:#555; text-decoration:none; font-size:0.7rem; margin-bottom:10px; border:1px dashed #333; padding:5px; border-radius:6px;">
                <i class="fas fa-download"></i> Download Blangko Excel
            </a>
            <form action="" method="POST" enctype="multipart/form-data">
                <input type="file" name="file_csv" accept=".csv" required>
                <button type="submit" name="upload_csv" class="btn" style="background:#16a34a;">UNGGAH CSV</button>
            </form>
        </div>
    </div>

    <div class="card">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
            <h2><i class="fas fa-list"></i> Data Tersimpan</h2>
            <div class="search-box">

                <input type="text" id="liveSearch" placeholder="Cari NIS / Nama...">
            </div>
        </div>
        
        <div class="table-wrapper">
            <table id="mainTable">
                <thead>
                    <tr>
                        <th style="text-align: center; width: 40px;">NO</th>
                        <th style="width: 120px;">NIS</th>
                        <th>NAMA LENGKAP</th>
                        <th style="text-align: center; width: 80px;">KELAS</th>
                        <th style="text-align: center; width: 60px;">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $res = mysqli_query($koneksi, "SELECT * FROM siswa ORDER BY kelas ASC, nama_murid ASC");
                    $no = 1;
                    if (mysqli_num_rows($res) > 0) {
                        while($row = mysqli_fetch_array($res)){
                            echo "<tr>
                                    <td style='text-align:center; color:#444; font-size:0.75rem;'>".$no++."</td>
                                    <td style='font-family:monospace; color:#a855f7;'>".$row['nis']."</td>
                                    <td class='target-cari'>".strtoupper($row['nama_murid'])."</td>
                                    <td style='text-align:center;'><span class='badge'>".$row['kelas']."</span></td>
                                    <td style='text-align:center;'>
                                        <a href='?hapus=".$row['nis']."' style='color:#444;' onmouseover='this.style.color=\"#ef4444\"' onmouseout='this.style.color=\"#444\"' onclick='return confirm(\"Hapus siswa ini?\")'>
                                            <i class='fas fa-trash-alt'></i>
                                        </a>
                                    </td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5' style='text-align:center; padding:30px; color:#444;'>Belum ada data.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
// Logika Pencarian Cepat (Live Search)
document.getElementById('liveSearch').addEventListener('keyup', function() {
    let input = this.value.toUpperCase();
    let rows = document.querySelector("#mainTable tbody").rows;

    for (let i = 0; i < rows.length; i++) {
        let nis = rows[i].cells[1].textContent.toUpperCase();
        let nama = rows[i].cells[2].textContent.toUpperCase();
        
        if (nis.includes(input) || nama.includes(input)) {
            rows[i].style.display = "";
        } else {
            rows[i].style.display = "none";
        }
    }
});
</script>

</body>
</html>