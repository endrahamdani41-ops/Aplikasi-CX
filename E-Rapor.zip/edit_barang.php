// Query untuk update nama saja
"UPDATE barang SET nama_barang = '$nama_baru' WHERE id_barang = '$id'"