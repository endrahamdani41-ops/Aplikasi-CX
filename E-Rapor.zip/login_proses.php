<?php
session_start();
include 'koneksi.php';

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = mysqli_real_escape_string($koneksi, $_POST['password']);

    // Query langsung ke tabel guru karena tabel users sudah dihapus
    $query = mysqli_query($koneksi, "SELECT * FROM guru WHERE username = '$username'");
    $data  = mysqli_fetch_assoc($query);

    if (mysqli_num_rows($query) > 0) {
        // Verifikasi password
        if ($password == $data['password']) {
            
            $_SESSION['login']      = true;
            $_SESSION['id_guru']    = $data['id'];
            $_SESSION['nama']       = $data['nama_guru'];
            $_SESSION['mapel']      = $data['mapel'];
            
            // Mengambil '8F' dari kolom wali_kelas di tabel guru
            $_SESSION['wali_kelas'] = $data['wali_kelas']; 

            header("Location: dashboard_guru.php");
            exit;
        } else {
            header("Location: index.php?pesan=password_salah");
            exit;
        }
    } else {
        header("Location: index.php?pesan=username_tidak_ditemukan");
        exit;
    }
}
?>