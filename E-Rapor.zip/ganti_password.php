<?php
session_start();
include 'koneksi.php'; // Hubungkan ke database

// 1. PROTEKSI HALAMAN
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: index.php");
    exit;
}

$id_user = $_SESSION['id_user'];
$error = "";
$success = "";

// 2. PROSES UPDATE PASSWORD
if (isset($_POST['update_password'])) {
    // Ambil data dari form dan amankan dari SQL Injection
    $pass_lama = mysqli_real_escape_string($koneksi, $_POST['password_lama']);
    $pass_baru = mysqli_real_escape_string($koneksi, $_POST['password_baru']);
    $konfirmasi = mysqli_real_escape_string($koneksi, $_POST['konfirmasi_password']);

    // Cek password lama di database (tabel users)
    $query_cek = mysqli_query($koneksi, "SELECT password FROM users WHERE id = '$id_user'");
    $data = mysqli_fetch_assoc($query_cek);

    if ($pass_lama !== $data['password']) {
        $error = "Password lama Anda salah!";
    } elseif ($pass_baru !== $konfirmasi) {
        $error = "Konfirmasi password baru tidak cocok!";
    } elseif (strlen($pass_baru) < 3) {
        $error = "Password baru terlalu pendek!";
    } else {
        // Eksekusi Update (Menggunakan teks biasa sesuai sistem login Anda saat ini)
        $sql_update = "UPDATE users SET password = '$pass_baru' WHERE id = '$id_user'";
        $update = mysqli_query($koneksi, $sql_update);

        if ($update) {
            $success = "Password berhasil diperbarui!";
        } else {
            $error = "Gagal memperbarui database: " . mysqli_error($koneksi);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ganti Password | E-Rapor Digital</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background-color: #050505; color: white; font-family: sans-serif; }
        .card { background-color: #0f0f0f; border: 1px solid #1a1a1a; }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen p-6">

    <div class="w-full max-w-md">
        <div class="text-center mb-8">
            <h1 class="text-2xl font-black italic text-purple-500 tracking-tighter">KEAMANAN AKUN</h1>
            <p class="text-gray-500 text-sm">Silakan perbarui kata sandi Anda.</p>
        </div>

        <?php if($error): ?>
            <div class="bg-red-500/10 border border-red-500/50 text-red-500 p-4 rounded-2xl mb-6 text-sm flex items-center gap-3">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <?php if($success): ?>
            <div class="bg-green-500/10 border border-green-500/50 text-green-500 p-4 rounded-2xl mb-6 text-sm flex items-center gap-3">
                <i class="fas fa-check-circle"></i> <?php echo $success; ?>
            </div>
        <?php endif; ?>

        <div class="card p-8 rounded-[2rem] shadow-2xl">
            <form action="" method="POST" class="space-y-6">
                <div>
                    <label class="block text-[10px] font-bold text-gray-500 uppercase tracking-[0.2em] mb-2 ml-1">Password Lama</label>
                    <input type="password" name="password_lama" required 
                        class="w-full bg-black border border-gray-800 p-4 rounded-2xl focus:border-purple-500 outline-none transition text-sm">
                </div>

                <div class="h-[1px] bg-gray-900 w-full"></div>

                <div>
                    <label class="block text-[10px] font-bold text-gray-500 uppercase tracking-[0.2em] mb-2 ml-1">Password Baru</label>
                    <input type="password" name="password_baru" required 
                        class="w-full bg-black border border-gray-800 p-4 rounded-2xl focus:border-purple-500 outline-none transition text-sm">
                </div>

                <div>
                    <label class="block text-[10px] font-bold text-gray-500 uppercase tracking-[0.2em] mb-2 ml-1">Konfirmasi Password</label>
                    <input type="password" name="konfirmasi_password" required 
                        class="w-full bg-black border border-gray-800 p-4 rounded-2xl focus:border-purple-500 outline-none transition text-sm">
                </div>

                <button type="submit" name="update_password" 
                    class="w-full bg-purple-600 hover:bg-purple-500 text-white font-black py-4 rounded-2xl transition-all shadow-lg shadow-purple-900/20 active:scale-95 text-xs tracking-widest">
                    SIMPAN PERUBAHAN
                </button>
            </form>

            <div class="mt-8 text-center">
                <a href="dashboard_guru.php" class="text-xs font-bold text-gray-600 hover:text-purple-400 transition uppercase tracking-widest">
                    <i class="fas fa-arrow-left mr-2"></i> Kembali
                </a>
            </div>
        </div>
    </div>

</body>
</html>