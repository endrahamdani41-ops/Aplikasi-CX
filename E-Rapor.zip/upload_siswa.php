<?php
session_start();
include 'koneksi.php';

if ($_SESSION['role'] != 'walikelas') {
    die("Akses Khusus Wali Kelas!");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Upload Siswa Kelas <?php echo $_SESSION['kelas']; ?></title>
    <style>
        body { background: #0f0f0f; color: white; font-family: 'Segoe UI', sans-serif; display: flex; justify-content: center; padding-top: 100px; }
        .upload-box { background: #1a1a1a; padding: 40px; border-radius: 15px; border: 1px solid #333; width: 450px; text-align: center; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
        h3 { color: #8e44ad; margin-bottom: 20px; }
        input[type="file"] { margin: 25px 0; color: #bbb; background: #252525; padding: 10px; border-radius: 5px; width: 100%; }
        button { background: #8e44ad; color: white; border: none; padding: 12px 25px; border-radius: 8px; cursor: pointer; font-weight: bold; width: 100%; transition: 0.3s; }
        button:hover { background: #9b59b6; }
        .info { font-size: 13px; color: #777; margin-top: 20px; line-height: 1.6; }
        .back-link { display: block; margin-top: 25px; color: #555; text-decoration: none; font-size: 14px; }
        .back-link:hover { color: #8e44ad; }
    </style>
</head>
<body>
    <div class="upload-box">
        <h3>Upload Siswa Kelas <?php echo $_SESSION['kelas']; ?></h3>
        <form action="proses_upload_siswa.php" method="POST" enctype="multipart/form-data">
            <input type="file" name="file_siswa" accept=".xlsx" required>
            <button type="submit" name="upload">UNGGAH FILE EXCEL</button>
        </form>
        <div class="info">
            Format: <b>File Excel (.xlsx)</b><br>
            Struktur Kolom: A = NIS, B = NAMA SISWA<br>
            (Data dimulai dari baris ke-2)
        </div>
        <a href="dashboard_guru.php" class="back-link"><i class="fas fa-arrow-left"></i> Kembali ke Dashboard</a>
    </div>
</body>
</html>