<?php
// Pastikan TIDAK ADA spasi atau baris kosong di atas tag <?php ini
session_start();
include 'koneksi.php';

$error = "";

if (isset($_POST['login'])) {
    $nis      = mysqli_real_escape_string($koneksi, $_POST['nis']);
    $password = mysqli_real_escape_string($koneksi, $_POST['password']);

    // Query ke tabel 'siswa'
    $query  = "SELECT * FROM nilaisiswa WHERE nis = '$nis' AND password = '$password'";
    $result = mysqli_query($koneksi, $query);

    if ($result) {
        if (mysqli_num_rows($result) === 1) {
            $data = mysqli_fetch_assoc($result);

            // Simpan session
            $_SESSION['login'] = true;
            $_SESSION['nis']   = $data['nis'];
            $_SESSION['nama']  = $data['nama'];

            // Redirect ke dashboard
            header("Location: dashboard_siswa.php");
            exit;
        } else {
            $error = "NIS atau Password salah!";
        }
    } else {
        // Jika query gagal, tampilkan pesan error dari database
        $error = "Masalah Database: " . mysqli_error($koneksi);
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Siswa - E-Rapor</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #0f172a; }
        .glass { background: rgba(30, 41, 59, 0.7); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.1); }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen p-4">

    <div class="glass p-8 rounded-3xl w-full max-w-md shadow-2xl">
        <div class="text-center mb-8">
            <div class="bg-purple-600 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-900/40 transform rotate-12">
                <i class="fas fa-user-graduate text-2xl text-white transform -rotate-12"></i>
            </div>
            <h2 class="text-2xl font-bold text-white tracking-tight">Portal Siswa</h2>
            <p class="text-slate-400 text-sm mt-1">Silakan masuk untuk melihat rapor</p>
        </div>

        <?php if ($error != ""): ?>
            <div class="bg-red-500/10 border border-red-500 text-red-500 p-3 rounded-xl text-sm mb-6 text-center">
                <i class="fas fa-exclamation-circle mr-2"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form action="" method="POST" class="space-y-5">
            <div>
                <label class="text-xs text-slate-400 ml-1 mb-1 block uppercase font-bold tracking-wider">NIS</label>
                <div class="relative">
                    <i class="fas fa-id-card absolute left-4 top-1/2 -translate-y-1/2 text-slate-500"></i>
                    <input type="text" name="nis" placeholder="Masukkan NIS" required
                           class="w-full pl-12 pr-4 py-3.5 rounded-xl bg-slate-900/50 border border-slate-700 text-white focus:border-purple-500 outline-none transition-all">
                </div>
            </div>

            <div>
                <label class="text-xs text-slate-400 ml-1 mb-1 block uppercase font-bold tracking-wider">Password</label>
                <div class="relative">
                    <i class="fas fa-lock absolute left-4 top-1/2 -translate-y-1/2 text-slate-500"></i>
                    <input type="password" name="password" placeholder="••••••••" required
                           class="w-full pl-12 pr-4 py-3.5 rounded-xl bg-slate-900/50 border border-slate-700 text-white focus:border-purple-500 outline-none transition-all">
                </div>
            </div>

            <button type="submit" name="login"
                    class="w-full py-4 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl transition-all shadow-lg uppercase tracking-widest text-sm mt-2">
                Masuk Ke Dashboard
            </button>
            
            <div class="text-center mt-6">
                <a href="index.php" class="text-slate-500 hover:text-white text-sm transition flex items-center justify-center gap-2">
                   <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </div>
        </form>
    </div>

</body>
</html>