<?php 
session_start();
if (!isset($_SESSION['login'])) { header("Location: login.php"); exit; }
?>
<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Riwayat Transaksi</title>
    <style>
        table { border-collapse: collapse; width: 90%; margin: 20px auto; font-family: Arial; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
        .masuk { color: green; font-weight: bold; }
        .keluar { color: red; font-weight: bold; }
    </style>
</head>
<body>
    <h2 style="text-align:center;">Log Aktivitas Stok</h2>
    <div style="text-align:center;"><a href="index.php">Kembali ke Dashboard</a></div>
    
    <table>
        <tr>
            <th>Waktu</th>
            <th>Nama Barang</th>
            <th>Tipe</th>
            <th>Jumlah</th>
            <th>Keterangan</th>
        </tr>
        <?php
        $sql = "SELECT riwayat_stok.*, barang.nama_barang 
                FROM riwayat_stok 
                JOIN barang ON riwayat_stok.id_barang = barang.id_barang 
                ORDER BY tanggal DESC";
        $query = mysqli_query($conn, $sql);
        while($row = mysqli_fetch_array($query)){
            $warna = ($row['tipe'] == 'masuk') ? 'masuk' : 'keluar';
            echo "<tr>
                    <td>{$row['tanggal']}</td>
                    <td>{$row['nama_barang']}</td>
                    <td class='$warna'>".strtoupper($row['tipe'])."</td>
                    <td>{$row['jumlah']}</td>
                    <td>{$row['keterangan']}</td>
                  </tr>";
        }
        ?>
    </table>
</body>
</html>