<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['login']) || !isset($_SESSION['nis'])) {
    header("Location: login_siswa.php");
    exit;
}

$nis_siswa = $_SESSION['nis'];
$nama_siswa = $_SESSION['nama'];

// Ambil data nilai siswa
$query = "SELECT * FROM nilaisiswa WHERE nis = '$nis_siswa'";
$result = mysqli_query($koneksi, $query);
$row = mysqli_fetch_assoc($result);

// Fungsi Logika Status
function getStatusRapor($u1, $u2, $ps) {
    $kkm = 82; 
    if ($u1 == 0 || $u2 == 0 || $ps == 0) {
        return '<span class="px-2 py-1 rounded-md text-[10px] bg-yellow-500/20 text-yellow-500 border border-yellow-500/40 font-bold uppercase">Belum Ulangan</span>';
    } elseif ($u1 < $kkm || $u2 < $kkm || $ps < $kkm) {
        return '<span class="px-2 py-1 rounded-md text-[10px] bg-red-500/20 text-red-500 border border-red-500/40 font-bold uppercase">Remedial</span>';
    } else {
        return '<span class="px-2 py-1 rounded-md text-[10px] bg-green-500/20 text-green-500 border border-green-500/40 font-bold uppercase">Tuntas</span>';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Hasil Belajar | E-Rapor</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #0f172a; color: #f8fafc; font-family: 'Inter', sans-serif; }
        .glass { background: rgba(30, 41, 59, 0.7); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.1); }
        
        /* Membuat garis tabel lebih tegas */
        .table-rapor { border-collapse: collapse; width: 100%; border: 2px solid #334155; }
        .table-rapor th { border: 2px solid #334155; background-color: #1e293b; color: #94a3b8; }
        .table-rapor td { border: 1px solid #334155; }
    </style>
</head>
<body class="min-h-screen p-4 md:p-8">

    <div class="max-w-6xl mx-auto">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
            <div>
                <h1 class="text-2xl font-bold text-white tracking-tight">Laporan Hasil Belajar (Rapor)</h1>
                <p class="text-slate-400 mt-1 uppercase text-xs tracking-widest font-bold">
                    Nama: <span class="text-purple-400"><?php echo $nama_siswa; ?></span> | NIS: <?php echo $nis_siswa; ?>
                </p>
            </div>
            <a href="dashboard_siswa.php" class="bg-slate-800 hover:bg-slate-700 text-white px-4 py-2 rounded-lg transition-all border border-slate-600 text-sm flex items-center gap-2">
                <i class="fas fa-arrow-left"></i>
            </a>
        </div>

        <div class="glass rounded-xl overflow-hidden shadow-2xl">
            <div class="overflow-x-auto">
                <table class="table-rapor text-left">
                    <thead>
                        <tr class="text-[11px] uppercase tracking-wider">
                            <th class="p-4 text-center w-12">No</th>
                            <th class="p-4">Mata Pelajaran</th>
                            <th class="p-4 text-center">KKM</th>
                            <th class="p-4 text-center">UH-1</th>
                            <th class="p-4 text-center">UH-2</th>
                            <th class="p-4 text-center">PSTS</th>
                            <th class="p-4 text-center">Keterangan</th>
                        </tr>
                    </thead>
                    <tbody class="text-sm">
                        <?php
                        $daftar_mapel = [
                            "Pendidikan Agama Islam" => "pai",
                            "Pendidikan Pancasila" => "pp",
                            "Bahasa Indonesia" => "bind",
                            "Matematika" => "mtk",
                            "Ilmu Pengetahuan Alam" => "ipa",
                            "Ilmu Pengetahuan Sosial" => "ips",
                            "Bahasa Inggris" => "bing",
                            "Seni Budaya" => "sbk",
                            "PJOK" => "pjok",
                            "Informatika" => "info"
                        ];

                        $no = 1;
                        foreach ($daftar_mapel as $nama_tampilan => $key) {
                            $u1 = $row['uh1_'.$key] ?? 0;
                            $u2 = $row['uh2_'.$key] ?? 0;
                            $ps = $row['psts_'.$key] ?? 0;
                        ?>
                        <tr class="hover:bg-white/5 transition">
                            <td class="p-4 text-center font-mono text-slate-500"><?php echo $no++; ?></td>
                            <td class="p-4 font-semibold text-white"><?php echo $nama_tampilan; ?></td>
                            <td class="p-4 text-center font-bold text-blue-400 bg-blue-500/5">82</td>
                            <td class="p-4 text-center"><?php echo $u1; ?></td>
                            <td class="p-4 text-center"><?php echo $u2; ?></td>
                            <td class="p-4 text-center"><?php echo $ps; ?></td>
                            <td class="p-4 text-center">
                                <?php echo getStatusRapor($u1, $u2, $ps); ?>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="mt-6 p-5 glass rounded-xl border-l-4 border-yellow-500">
            <div class="flex gap-3">
                <i class="fas fa-exclamation-triangle text-yellow-500 mt-1"></i>
                <div class="text-[11px] text-slate-400 space-y-1">
                    <p><b class="text-white">Informasi:</b> KKM untuk seluruh mata pelajaran adalah <b>82</b>.</p>
                    <p>Jika terdapat nilai <b>0</b>, sistem secara otomatis memberikan keterangan <b>Belum Ulangan</b>.</p>
                    <p>Silakan hubungi Guru Mata Pelajaran jika terdapat ketidaksesuaian data nilai.</p>
                </div>
            </div>
        </div>
    </div>

</body>
</html>