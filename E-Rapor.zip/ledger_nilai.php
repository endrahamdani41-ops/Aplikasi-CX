<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['login'])) {
    header("Location: index.php");
    exit;
}

// Konfigurasi Khusus Wali Kelas 8F
$kelas_wali = "8F"; 
$nama_guru  = "ENDRA TRIYANTO HAMDANI, S.Kom.";

/** * QUERY PIVOT (Mengubah data vertikal menjadi horizontal)
 * Mengambil data dari tabel 'nilai' berdasarkan struktur image_be3b83.png
 */
$query_str = "SELECT nis, nama_murid, 
    MAX(CASE WHEN mapel = 'PENDIDIKAN AGAMA ISLAM' THEN uh1 ELSE 0 END) as u1_pai,
    MAX(CASE WHEN mapel = 'PENDIDIKAN AGAMA ISLAM' THEN uh2 ELSE 0 END) as u2_pai,
    MAX(CASE WHEN mapel = 'PENDIDIKAN AGAMA ISLAM' THEN asts ELSE 0 END) as as_pai,
    
    MAX(CASE WHEN mapel = 'PENDIDIKAN PANCASILA' THEN uh1 ELSE 0 END) as u1_pp,
    MAX(CASE WHEN mapel = 'PENDIDIKAN PANCASILA' THEN uh2 ELSE 0 END) as u2_pp,
    MAX(CASE WHEN mapel = 'PENDIDIKAN PANCASILA' THEN asts ELSE 0 END) as as_pp,
    
    MAX(CASE WHEN mapel = 'BAHASA INDONESIA' THEN uh1 ELSE 0 END) as u1_ind,
    MAX(CASE WHEN mapel = 'BAHASA INDONESIA' THEN uh2 ELSE 0 END) as u2_ind,
    MAX(CASE WHEN mapel = 'BAHASA INDONESIA' THEN asts ELSE 0 END) as as_ind,
    
    MAX(CASE WHEN mapel = 'MATEMATIKA' THEN uh1 ELSE 0 END) as u1_mtk,
    MAX(CASE WHEN mapel = 'MATEMATIKA' THEN uh2 ELSE 0 END) as u2_mtk,
    MAX(CASE WHEN mapel = 'MATEMATIKA' THEN asts ELSE 0 END) as as_mtk,
    
    MAX(CASE WHEN mapel = 'IPA' THEN uh1 ELSE 0 END) as u1_ipa,
    MAX(CASE WHEN mapel = 'IPA' THEN uh2 ELSE 0 END) as u2_ipa,
    MAX(CASE WHEN mapel = 'IPA' THEN asts ELSE 0 END) as as_ipa,
    
    MAX(CASE WHEN mapel = 'IPS' THEN uh1 ELSE 0 END) as u1_ips,
    MAX(CASE WHEN mapel = 'IPS' THEN uh2 ELSE 0 END) as u2_ips,
    MAX(CASE WHEN mapel = 'IPS' THEN asts ELSE 0 END) as as_ips,
    
    MAX(CASE WHEN mapel = 'BAHASA INGGRIS' THEN uh1 ELSE 0 END) as u1_ing,
    MAX(CASE WHEN mapel = 'BAHASA INGGRIS' THEN uh2 ELSE 0 END) as u2_ing,
    MAX(CASE WHEN mapel = 'BAHASA INGGRIS' THEN asts ELSE 0 END) as as_ing,
    
    MAX(CASE WHEN mapel = 'PJOK' THEN uh1 ELSE 0 END) as u1_pjok,
    MAX(CASE WHEN mapel = 'PJOK' THEN uh2 ELSE 0 END) as u2_pjok,
    MAX(CASE WHEN mapel = 'PJOK' THEN asts ELSE 0 END) as as_pjok,
    
    MAX(CASE WHEN mapel = 'INFORMATIKA' THEN uh1 ELSE 0 END) as u1_inf,
    MAX(CASE WHEN mapel = 'INFORMATIKA' THEN uh2 ELSE 0 END) as u2_inf,
    MAX(CASE WHEN mapel = 'INFORMATIKA' THEN asts ELSE 0 END) as as_inf,
    
    MAX(CASE WHEN mapel = 'SENI BUDAYA' THEN uh1 ELSE 0 END) as u1_sbk,
    MAX(CASE WHEN mapel = 'SENI BUDAYA' THEN uh2 ELSE 0 END) as u2_sbk,
    MAX(CASE WHEN mapel = 'SENI BUDAYA' THEN asts ELSE 0 END) as as_sbk,

    AVG(rata_rata) as total_rata
    FROM nilai 
    WHERE kelas = '$kelas_wali' 
    GROUP BY nis, nama_murid 
    ORDER BY nama_murid ASC";

$query = mysqli_query($koneksi, $query_str);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Ledger 8F - <?php echo $nama_guru; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f1f5f9; }
        .sheet { 
            background: white; padding: 25px; margin: 20px auto; 
            width: 98%; max-width: 1800px; box-shadow: 0 10px 15px rgba(0,0,0,0.1); 
            border-radius: 12px;
        }
        
        /* Font diperbesar menjadi 12px untuk isi tabel */
        table { 
            width: 100%; border-collapse: collapse; 
            font-size: 12px; color: #111; 
        }
        
        th, td { border: 1.5px solid #000; padding: 6px 2px; text-align: center; }
        th { background: #f3f4f6; font-weight: 800; font-size: 10px; }
        
        .nama-col { 
            text-align: left; padding-left: 10px; width: 220px; 
            font-weight: bold; text-transform: uppercase;
        }

        .no-print-btn {
            background: #9333ea; color: white; padding: 10px 25px;
            border-radius: 50px; font-weight: bold; transition: 0.3s;
        }

        @media print {
            .no-print { display: none !important; }
            .sheet { margin: 0; width: 100%; box-shadow: none; border-radius: 0; padding: 0; }
            body { background: white; }
            /* Menyesuaikan ukuran saat print agar tidak meluap */
            table { font-size: 10px; } 
            @page { size: landscape; margin: 0.5cm; }
        }
    </style>
</head>
<body class="p-4">

    <div class="no-print flex justify-center gap-4 mb-8">
        <a href="dashboard_guru.php" class="bg-gray-700 text-white px-6 py-2 rounded-full font-bold self-center"><i class="fas fa-arrow-left mr-2"></i> KEMBALI</a>
        <button onclick="window.print()" class="no-print-btn shadow-lg hover:bg-purple-700">
            <i class="fas fa-print mr-2"></i> CETAK LEDGER KELAS 8F
        </button>
    </div>

    <div class="sheet">
        <div class="text-center mb-6">
            <h1 class="text-3xl font-black uppercase tracking-tight border-b-4 border-black inline-block pb-2">Ledger Nilai Peserta Didik</h1>
            <div class="flex justify-center gap-10 mt-4 font-bold text-lg">
                <p>KELAS: <span class="text-purple-700"><?php echo $kelas_wali; ?></span></p>
                <p>WALI KELAS: <span class="text-purple-700"><?php echo $nama_guru; ?></span></p>
            </div>
            <p class="italic text-gray-500 mt-1">Tahun Pelajaran 2025/2026 - SMP NEGERI 110 JAKARTA</p>
        </div>

        <table>
            <thead>
                <tr>
                    <th rowspan="2" width="30">NO</th>
                    <th rowspan="2" class="nama-col">NAMA LENGKAP SISWA</th>
                    <th rowspan="2" width="70">NIS</th>
                    <th colspan="3">PAI</th>
                    <th colspan="3">PP</th>
                    <th colspan="3">IND</th>
                    <th colspan="3">MTK</th>
                    <th colspan="3">IPA</th>
                    <th colspan="3">IPS</th>
                    <th colspan="3">ING</th>
                    <th colspan="3">PJOK</th>
                    <th colspan="3">INF</th>
                    <th colspan="3">SBK</th>
                    <th rowspan="2" width="50" class="bg-gray-100">RATA</th>
                </tr>
                <tr>
                    <?php for($i=0; $i<10; $i++) echo "<th>U1</th><th>U2</th><th>AS</th>"; ?>
                </tr>
            </thead>
            <tbody>
                <?php 
                $no = 1; 
                while($row = mysqli_fetch_assoc($query)): 
                ?>
                <tr class="hover:bg-gray-50">
                    <td><?php echo $no++; ?></td>
                    <td class="nama-col"><?php echo htmlspecialchars($row['nama_murid']); ?></td>
                    <td class="font-mono"><?php echo $row['nis']; ?></td>
                    
                    <td><?php echo $row['u1_pai']; ?></td><td><?php echo $row['u2_pai']; ?></td><td><?php echo $row['as_pai']; ?></td>
                    <td><?php echo $row['u1_pp']; ?></td><td><?php echo $row['u2_pp']; ?></td><td><?php echo $row['as_pp']; ?></td>
                    <td><?php echo $row['u1_ind']; ?></td><td><?php echo $row['u2_ind']; ?></td><td><?php echo $row['as_ind']; ?></td>
                    <td><?php echo $row['u1_mtk']; ?></td><td><?php echo $row['u2_mtk']; ?></td><td><?php echo $row['as_mtk']; ?></td>
                    <td><?php echo $row['u1_ipa']; ?></td><td><?php echo $row['u2_ipa']; ?></td><td><?php echo $row['as_ipa']; ?></td>
                    <td><?php echo $row['u1_ips']; ?></td><td><?php echo $row['u2_ips']; ?></td><td><?php echo $row['as_ips']; ?></td>
                    <td><?php echo $row['u1_ing']; ?></td><td><?php echo $row['u2_ing']; ?></td><td><?php echo $row['as_ing']; ?></td>
                    <td><?php echo $row['u1_pjok']; ?></td><td><?php echo $row['u2_pjok']; ?></td><td><?php echo $row['as_pjok']; ?></td>
                    <td><?php echo $row['u1_inf']; ?></td><td><?php echo $row['u2_inf']; ?></td><td><?php echo $row['as_inf']; ?></td>
                    <td><?php echo $row['u1_sbk']; ?></td><td><?php echo $row['u2_sbk']; ?></td><td><?php echo $row['as_sbk']; ?></td>

                    <td class="font-bold bg-gray-50"><?php echo number_format($row['total_rata'], 1); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <div class="mt-10 flex justify-end">
            <div class="text-center w-80 text-sm">
                <p>Jakarta, <?php echo date('d F Y'); ?></p>
                <p class="font-black mt-1">Wali Kelas,</p>
                <div class="h-24"></div>
                <p class="font-black underline uppercase"><?php echo $nama_guru; ?></p>
                <p class="text-xs">NIP. .......................................</p>
            </div>
        </div>
    </div>

</body>
</html>