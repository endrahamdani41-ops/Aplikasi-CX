<?php
session_start();
include 'koneksi.php';

// Jika sudah login, langsung lempar ke dashboard sesuai role masing-masing
if (isset($_SESSION['login']) && $_SESSION['login'] === true) {
    if ($_SESSION['role'] == 'admin') header("Location: dashboard_admin.php");
    elseif ($_SESSION['role'] == 'guru') header("Location: dashboard_guru.php");
    elseif ($_SESSION['role'] == 'siswa') header("Location: dashboard_siswa.php");
    exit;
}

$error = false;

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($koneksi, trim($_POST['username']));
    $password = $_POST['password'];

    // Perbaikan: Mencari di tabel 'guru'. Kolom yang ada adalah 'username' dan 'nip' (bukan nomor_induk)
    $query = mysqli_query($koneksi, "SELECT * FROM guru WHERE username = '$username' OR nip = '$username' LIMIT 1");

    if ($query && mysqli_num_rows($query) === 1) {
        $row = mysqli_fetch_assoc($query);

        // Verifikasi password (teks biasa 'guru123')
        if ($password === $row['password']) {
            
            // Set Session sesuai struktur tabel guru Anda
            $_SESSION['login']      = true;
            $_SESSION['id_user']    = $row['id'];
            $_SESSION['username']   = $row['username'];
            $_SESSION['nama']       = $row['nama_guru']; // Sesuaikan: nama_guru
            $_SESSION['role']       = strtolower($row['role']); 
            $_SESSION['nip']        = $row['nip']; // Sesuaikan: nip
            $_SESSION['mapel']      = $row['mapel'];
            $_SESSION['wali_kelas'] = $row['wali_kelas']; // Sesuaikan: wali_kelas

            // Redirect otomatis berdasarkan role
            if ($_SESSION['role'] == 'admin') {
                header("Location: dashboard_admin.php");
            } elseif ($_SESSION['role'] == 'guru') {
                header("Location: dashboard_guru.php");
            } else {
                header("Location: dashboard_siswa.php");
            }
            exit;
        } else {
            $error = "Password yang Anda masukkan salah!";
        }
    } else {
        $error = "ID Pengguna tidak ditemukan di sistem!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login E-Rapor Digital</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap');
        body { background-color: #050505; color: white; font-family: 'Plus Jakarta Sans', sans-serif; }
        .login-card { background-color: #0a0a0a; border: 1px solid #1a1a1a; }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen p-4">

<div class="login-card w-full max-w-md p-10 rounded-[2.5rem] shadow-2xl">
    <div class="text-center mb-10">
        <div class="w-20 h-20 bg-purple-600/10 rounded-3xl flex items-center justify-center mx-auto mb-6 border border-purple-500/20 rotate-3">
            <i class="fas fa-shield-halved text-4xl text-purple-500 -rotate-3"></i>
        </div>
        <h2 class="text-2xl font-black italic tracking-tighter uppercase">E-RAPOR <span class="text-purple-500">DIGITAL</span></h2>
        <p class="text-gray-500 text-[10px] mt-2 font-bold uppercase tracking-[0.3em]">SMPN 110 JAKARTA</p>
    </div>

    <?php if ($error) : ?>
        <div class="bg-red-500/10 border border-red-500/20 text-red-500 text-[11px] font-bold p-4 rounded-2xl mb-6 flex items-center gap-3 italic uppercase">
            <i class="fas fa-triangle-exclamation"></i>
            <span><?php echo $error; ?></span>
        </div>
    <?php endif; ?>

    <form action="" method="post" class="space-y-6">
        <div>
            <label class="text-gray-500 text-[10px] font-black uppercase tracking-widest block mb-2 ml-1">Username / NIP</label>
            <div class="relative">
                <i class="fas fa-id-card absolute left-4 top-1/2 -translate-y-1/2 text-gray-700"></i>
                <input type="text" name="username" placeholder="Contoh: guru10" class="w-full bg-[#0f0f0f] border border-gray-800 p-4 pl-12 rounded-2xl outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition text-sm font-medium" required autofocus>
            </div>
        </div>
        
        <div>
            <label class="text-gray-500 text-[10px] font-black uppercase tracking-widest block mb-2 ml-1">Password</label>
            <div class="relative">
                <i class="fas fa-key absolute left-4 top-1/2 -translate-y-1/2 text-gray-700"></i>
                <input type="password" name="password" placeholder="••••••••" class="w-full bg-[#0f0f0f] border border-gray-800 p-4 pl-12 rounded-2xl outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition text-sm font-medium" required>
            </div>
        </div>

        <button type="submit" name="login" class="w-full bg-purple-600 hover:bg-purple-700 text-white font-black py-4 rounded-2xl transition transform active:scale-95 shadow-xl shadow-purple-900/20 uppercase tracking-widest text-xs italic">
            Masuk Sekarang
        </button>
    </form>

    <div class="mt-10 pt-8 border-t border-gray-900 text-center">
        <p class="text-gray-700 text-[9px] uppercase font-black tracking-widest leading-loose">
            Portal Penilaian Akademik Terpadu<br>
            &copy; <?php echo date('Y'); ?> Versi 3.0 Stable
        </p>
    </div>
</div>

</body>
</html>