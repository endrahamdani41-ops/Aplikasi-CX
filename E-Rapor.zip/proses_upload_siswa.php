<?php
session_start();
include 'koneksi.php';

// Memanggil library SimpleXLSX dengan Namespace yang benar
require_once 'SimpleXLSX.php';
use Shuchkin\SimpleXLSX; 

if (isset($_POST['upload'])) {
    $kelas = $_SESSION['kelas'];
    
    // Pastikan file benar-benar terupload
    if (isset($_FILES['file_siswa']) && $_FILES['file_siswa']['error'] === UPLOAD_ERR_OK) {
        
        // Memproses file Excel
        if ($xlsx = SimpleXLSX::parse($_FILES['file_siswa']['tmp_name'])) {
            $count = 0;
            $rows = $xlsx->rows();
            
            // Perulangan mulai dari baris ke-2 (index 1) untuk melewati header
            for ($i = 1; $i < count($rows); $i++) {
                $nis  = mysqli_real_escape_string($koneksi, $rows[$i][0]); // Kolom A
                $nama = mysqli_real_escape_string($koneksi, $rows[$i][1]); // Kolom B

                if (!empty($nis) && !empty($nama)) {
                    // Query Simpan/Update
                    $sql = "INSERT INTO nilaisiswa (nis, nama, kelas) 
                            VALUES ('$nis', '$nama', '$kelas') 
                            ON DUPLICATE KEY UPDATE nama='$nama', kelas='$kelas'";
                    
                    if (mysqli_query($koneksi, $sql)) {
                        $count++;
                    }
                }
            }

            echo "<script>
                    alert('Berhasil! $count data siswa kelas $kelas telah diperbarui.'); 
                    window.location='dashboard_guru.php';
                  </script>";
        } else {
            // Menampilkan error jika file Excel gagal dibaca
            echo "Format Excel tidak valid: " . SimpleXLSX::parseError();
        }
    } else {
        echo "Gagal mengunggah file. Silakan coba lagi.";
    }
} else {
    header("Location: upload_siswa.php");
}
?>