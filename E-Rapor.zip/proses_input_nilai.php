<?php
session_start();
include 'koneksi.php';

// 1. Ambil Parameter
$kelas_pilihan = isset($_GET['kelas']) ? mysqli_real_escape_string($koneksi, $_GET['kelas']) : '';
$mapel = isset($_SESSION['mapel']) ? $_SESSION['mapel'] : 'INFORMATIKA';

if (empty($kelas_pilihan)) {
    die("Gagal: Kelas tidak dipilih. <a href='input_nilai.php'>Kembali</a>");
}

// 2. Query Data (Gabungkan Tabel Siswa dan Tabel Nilai)
$sql = "SELECT s.nama_murid, s.nis, s.kelas,
               IFNULL(n.uh1, 0) as uh1, 
               IFNULL(n.uh2, 0) as uh2, 
               IFNULL(n.asts, 0) as asts
        FROM siswa s
        LEFT JOIN nilai n ON s.nis = n.nis AND n.mapel = '$mapel'
        WHERE s.kelas = '$kelas_pilihan' 
        ORDER BY s.nama_murid ASC";

$query_siswa = mysqli_query($koneksi, $sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Nilai - <?= $kelas_pilihan ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap');
        
        body { background-color: #050505; color: white; font-family: 'Plus Jakarta Sans', sans-serif; }
        
        .input-box { 
            background: black; 
            border: 1px solid #1a1a1a; 
            transition: all 0.3s; 
        }
        
        .input-box:focus { 
            border-color: #a855f7; 
            box-shadow: 0 0 10px rgba(168, 85, 247, 0.2); 
            outline: none; 
        }

        /* HILANGKAN SPINNER (PANAH NAIK TURUN) */
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
        input[type=number] { -moz-appearance: textfield; }
    </style>
</head>
<body class="p-6 md:p-10">

    <div class="max-w-6xl mx-auto">
        <div class="flex justify-between items-end mb-6">
            <div>
                <h1 class="text-3xl font-black italic uppercase tracking-tighter text-white">INPUT <span class="text-purple-500">NILAI SISWA</span></h1>
                <p class="text-gray-500 font-bold uppercase text-[10px] tracking-[0.3em] mt-1">
                    <?= $mapel ?> <span class="mx-2 text-gray-800">|</span> KELAS <?= $kelas_pilihan ?>
                </p>
            </div>
            <a href="dashboard_guru.php?page=input_nilai" class="bg-gray-900 hover:bg-gray-800 text-white px-5 py-2 rounded-xl text-xs font-bold transition">
                <i class="fas fa-arrow-left mr-2"></i> Kembali
            </a>
        </div>

        <form action="simpan_nilai.php" method="POST">
            <input type="hidden" name="mapel" value="<?= $mapel ?>">
            <input type="hidden" name="kelas" value="<?= $kelas_pilihan ?>">

            <div class="bg-[#0f0f0f] border border-gray-900 rounded-[2rem] overflow-hidden shadow-2xl">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-gray-900/40 text-[11px] font-black uppercase tracking-[0.25em] text-gray-400 border-b border-gray-800">
                            <th class="py-5 px-6 text-center">NO</th>
                            <th class="py-5 px-6">NIS</th>
                            <th class="py-5 px-6">NAMA LENGKAP</th>
                            <th class="py-5 px-6 text-center">UH 1</th>
                            <th class="py-5 px-6 text-center">UH 2</th>
                            <th class="py-5 px-6 text-center">ASTS</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-900">
                        <?php 
                        $no = 1;
                        if(mysqli_num_rows($query_siswa) > 0) {
                            while($s = mysqli_fetch_array($query_siswa)) { ?>
                            <tr class="hover:bg-white/[0.01] transition">
                                <td class="py-2.5 px-6 text-center text-gray-600 font-bold text-sm"><?= $no++ ?></td>
                                <td class="py-2.5 px-6 text-gray-500 font-mono text-xs"><?= $s['nis'] ?></td>
                                <td class="py-2.5 px-6">
                                    <p class="text-white font-bold tracking-tight text-sm uppercase"><?= $s['nama_murid'] ?></p>
                                    
                                    <input type="hidden" name="nis[]" value="<?= $s['nis'] ?>">
                                    <input type="hidden" name="nama_murid[]" value="<?= $s['nama_murid'] ?>">
                                </td>
                                <td class="py-2.5 px-6 text-center">
                                    <input type="number" name="uh1[]" value="<?= $s['uh1'] ?>" class="w-16 input-box p-2 rounded-lg text-center font-black text-purple-400 text-sm">
                                </td>
                                <td class="py-2.5 px-6 text-center">
                                    <input type="number" name="uh2[]" value="<?= $s['uh2'] ?>" class="w-16 input-box p-2 rounded-lg text-center font-black text-purple-400 text-sm">
                                </td>
                                <td class="py-2.5 px-6 text-center">
                                    <input type="number" name="asts[]" value="<?= $s['asts'] ?>" class="w-16 input-box p-2 rounded-lg text-center font-black text-blue-400 text-sm">
                                </td>
                            </tr>
                        <?php } 
                        } ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-6 flex gap-4">
                <button type="submit" class="flex-[3] bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white font-black italic uppercase py-4 rounded-2xl transition shadow-lg tracking-widest text-xs">
                    SIMPAN SEMUA DATA <i class="fas fa-save ml-2"></i>
                </button>
                
                <a href="print_daftar_nilai.php?kelas=<?= $kelas_pilihan ?>" target="_blank" class="flex-1 bg-gray-900 hover:bg-gray-800 border border-gray-800 text-white text-center py-4 rounded-2xl transition font-black italic uppercase tracking-widest text-xs flex items-center justify-center">
                    <i class="fas fa-print mr-2"></i> CETAK
                </a>
            </div>
        </form>
    </div>

    <footer class="mt-10 text-center text-[9px] text-gray-800 font-bold uppercase tracking-[0.5em]">
        E-Rapor Digital &copy; 2026
    </footer>

</body>
</html>