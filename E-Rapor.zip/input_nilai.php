<?php
session_start();
include 'koneksi.php';

// 1. PROTEKSI HALAMAN
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: index.php");
    exit;
}

// 2. AMBIL DATA DARI SESSION
// Kita gunakan NAMA_LENGKAP Pak Endra sesuai tabel guru
$nama_guru_session = $_SESSION['nama']; 
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Nilai | E-Rapor Digital</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap');
        body { background-color: #050505; color: white; font-family: 'Plus Jakarta Sans', sans-serif; }
        .card { background-color: #0f0f0f; border: 1px solid #1a1a1a; }
        select option { background-color: #0f0f0f; color: white; }
    </style>
</head>
<body class="p-10">

    <div class="max-w-4xl mx-auto">
        <div class="mb-8 flex items-center justify-between">
            <div>
                <h1 class="text-3xl font-black italic uppercase tracking-tighter">Input <span class="text-purple-500">Nilai Siswa</span></h1>
                <p class="text-gray-500">Pilih kelas yang Anda ampu untuk mulai menginput nilai.</p>
            </div>
            <a href="dashboard_guru.php" class="bg-gray-800 hover:bg-gray-700 text-white px-5 py-2 rounded-xl text-sm font-bold transition">
                <i class="fas fa-arrow-left mr-2"></i> Dashboard
            </a>
        </div>

        <div class="card p-8 rounded-[2.5rem]">
            <form action="proses_input_nilai.php" method="GET">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    
                    <div>
                        <label class="block text-[10px] font-bold text-gray-500 uppercase tracking-[0.2em] mb-3">Pilih Kelas</label>
                        <select name="kelas" required class="w-full bg-[#050505] border border-gray-800 text-white p-4 rounded-2xl focus:border-purple-500 outline-none transition appearance-none">
                            <option value="">-- Pilih Kelas --</option>
                            <?php
                            /** * QUERY DINAMIS: 
                             * Mengambil data dari tabel 'guru_ampu' berdasarkan nama guru.
                             * Gunakan LIKE agar lebih fleksibel terhadap spasi atau gelar.
                             */
                            $query_ampu = mysqli_query($koneksi, "SELECT DISTINCT kelas FROM guru_ampu WHERE nama_guru LIKE '%$nama_guru_session%' ORDER BY kelas ASC");
                            
                            if(mysqli_num_rows($query_ampu) > 0) {
                                while($row = mysqli_fetch_array($query_ampu)) {
                                    echo "<option value='".$row['kelas']."'>KELAS ".$row['kelas']."</option>";
                                }
                            } else {
                                echo "<option value=''>Data kelas tidak ditemukan</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-[10px] font-bold text-gray-500 uppercase tracking-[0.2em] mb-3">Mata Pelajaran</label>
                        <input type="text" value="<?= $_SESSION['mapel']; ?>" readonly class="w-full bg-gray-900/30 border border-gray-800 text-gray-500 p-4 rounded-2xl cursor-not-allowed">
                    </div>
                </div>

                <div class="mt-10">
                    <button type="submit" class="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white font-black italic uppercase py-5 rounded-2xl transition shadow-xl shadow-purple-500/20 tracking-widest text-sm">
                        Buka Form Nilai <i class="fas fa-chevron-right ml-2"></i>
                    </button>
                </div>
            </form>
        </div>

        <div class="mt-8 p-6 border border-dashed border-gray-800 rounded-2xl opacity-50">
            <h4 class="text-[10px] font-bold text-gray-600 uppercase mb-2 italic">Sistem Debugger:</h4>
            <p class="text-xs text-gray-500">
                Nama Terdeteksi: <b><?= $nama_guru_session ?></b><br>
                Jika daftar kelas masih kosong, pastikan nama di atas sama persis dengan kolom <b>nama_guru</b> di tabel <b>guru_ampu</b>.
            </p>
        </div>
    </div>

</body>
</html>