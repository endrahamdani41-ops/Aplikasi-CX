<?php
session_start();
include 'koneksi.php';

// Proteksi Login
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Ambil ID dari URL
if (!isset($_GET['id'])) {
    header("Location: data_guru.php");
    exit;
}

$id = $_GET['id'];
$query_guru = mysqli_query($koneksi, "SELECT * FROM guru WHERE id = '$id'");
$data = mysqli_fetch_assoc($query_guru);

// Jika data guru tidak ditemukan
if (!$data) {
    header("Location: data_guru.php");
    exit;
}

// Ambil daftar kelas yang sudah diampu guru ini dari tabel guru_ampu
$nama_guru_lama = $data['nama_guru'];
$q_ampu = mysqli_query($koneksi, "SELECT kelas FROM guru_ampu WHERE nama_guru = '$nama_guru_lama'");
$kelas_aktif = [];
while ($row_ampu = mysqli_fetch_assoc($q_ampu)) {
    $kelas_aktif[] = $row_ampu['kelas'];
}

// PROSES UPDATE DATA
if (isset($_POST['update'])) {
    $nip = mysqli_real_escape_string($koneksi, $_POST['nip']);
    $nama_baru = mysqli_real_escape_string($koneksi, $_POST['nama_guru']);
    $mapel = mysqli_real_escape_string($koneksi, $_POST['mapel']);
    $wali = mysqli_real_escape_string($koneksi, $_POST['wali_kelas']);
    $user = mysqli_real_escape_string($koneksi, $_POST['username']);
    $pass = mysqli_real_escape_string($koneksi, $_POST['password']);
    
    // Array kelas ampu baru dari checkbox
    $kelas_ampu_baru = isset($_POST['kelas_ampu']) ? $_POST['kelas_ampu'] : [];

    // 1. Update Tabel Guru Utama
    $update_main = mysqli_query($koneksi, "UPDATE guru SET 
        nip = '$nip', 
        nama_guru = '$nama_baru', 
        mapel = '$mapel', 
        wali_kelas = '$wali', 
        username = '$user', 
        password = '$pass' 
        WHERE id = '$id'");

    if ($update_main) {
        // 2. Sinkronisasi Tabel guru_ampu
        // Hapus data lama agar tidak duplikat
        mysqli_query($koneksi, "DELETE FROM guru_ampu WHERE nama_guru = '$nama_guru_lama'");

        // Simpan data ampu baru yang dipilih
        if (!empty($kelas_ampu_baru)) {
            foreach ($kelas_ampu_baru as $kls) {
                mysqli_query($koneksi, "INSERT INTO guru_ampu (nama_guru, kelas, mapel) 
                                       VALUES ('$nama_baru', '$kls', '$mapel')");
            }
        }

        // NOTIFIKASI BERHASIL DAN REDIRECT
        echo "<script>
                alert('Berhasil! Data guru $nama_baru telah diperbarui.');
                window.location='data_guru.php';
              </script>";
        exit;
    } else {
        echo "<script>alert('Gagal memperbarui data!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Guru | E-Rapor Digital</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap');
        body { background-color: #050505; color: white; font-family: 'Plus Jakarta Sans', sans-serif; }
        .glass-card { background: #0f0f0f; border: 1px solid #1a1a1a; border-radius: 24px; }
        .input-dark { background: #000; border: 1px solid #222; color: white; padding: 12px; border-radius: 12px; width: 100%; transition: all 0.3s; font-size: 14px; }
        .input-dark:focus { border-color: #a855f7; outline: none; box-shadow: 0 0 15px rgba(168, 85, 247, 0.1); }
        .cb-label { transition: all 0.2s; border: 1px solid #222; cursor: pointer; display: block; }
        .cb-ampu:checked + .cb-label { background: #a855f7; border-color: #a855f7; color: white; }
    </style>
</head>
<body class="p-6 flex justify-center items-center min-h-screen">

    <div class="w-full max-w-4xl">
        <div class="flex justify-between items-center mb-6">
            <div>
                <h1 class="text-2xl font-black italic uppercase tracking-tighter text-white">EDIT <span class="text-purple-500 text-3xl">GURU</span></h1>
                <p class="text-gray-500 text-[10px] font-bold uppercase tracking-widest">Update data dan pembagian kelas</p>
            </div>
            <a href="data_guru.php" class="bg-gray-900 border border-gray-800 px-5 py-2 rounded-xl text-[10px] font-bold uppercase hover:bg-white hover:text-black transition">Batal / Kembali</a>
        </div>

        <form action="" method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            <div class="glass-card p-8 space-y-5">
                <h2 class="text-[11px] font-black text-purple-500 uppercase tracking-[0.2em] mb-4 italic"><i class="fas fa-user-edit mr-2"></i>Informasi Profil</h2>
                
                <div class="space-y-4">
                    <div>
                        <label class="text-[10px] text-gray-500 font-bold ml-1 uppercase">NIP / Nomor Induk</label>
                        <input type="text" name="nip" value="<?= $data['nip'] ?>" class="input-dark mt-1" required>
                    </div>

                    <div>
                        <label class="text-[10px] text-gray-500 font-bold ml-1 uppercase">Nama Lengkap</label>
                        <input type="text" name="nama_guru" value="<?= $data['nama_guru'] ?>" class="input-dark mt-1" required>
                    </div>

                    <div>
                        <label class="text-[10px] text-gray-500 font-bold ml-1 uppercase">Mata Pelajaran</label>
                        <input type="text" name="mapel" value="<?= $data['mapel'] ?>" class="input-dark mt-1" required>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="text-[10px] text-gray-500 font-bold ml-1 uppercase">Username</label>
                            <input type="text" name="username" value="<?= $data['username'] ?>" class="input-dark mt-1" required>
                        </div>
                        <div>
                            <label class="text-[10px] text-gray-500 font-bold ml-1 uppercase">Password</label>
                            <input type="text" name="password" value="<?= $data['password'] ?>" class="input-dark mt-1" required>
                        </div>
                    </div>
                </div>
            </div>

            <div class="glass-card p-8 flex flex-col justify-between">
                <div>
                    <h2 class="text-[11px] font-black text-blue-500 uppercase tracking-[0.2em] mb-4 italic"><i class="fas fa-chalkboard mr-2"></i>Penugasan Kelas</h2>
                    
                    <div class="mb-6">
                        <label class="text-[10px] text-blue-400 font-bold ml-1 uppercase">Tugas Wali Kelas:</label>
                        <select name="wali_kelas" class="input-dark mt-1">
                            <option value="-">Bukan Wali Kelas</option>
                            <?php
                            $list_kelas = ['7A','7B','7C','7D','7E','7F','8A','8B','8C','8D','8E','8F','9A','9B','9C','9D'];
                            foreach($list_kelas as $kls) {
                                $selected = ($data['wali_kelas'] == $kls) ? 'selected' : '';
                                echo "<option value='$kls' $selected>Wali Kelas $kls</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <label class="text-[10px] text-purple-400 font-bold ml-1 uppercase">Kelas Mengajar (Ampu):</label>
                    <div class="grid grid-cols-4 gap-2 mt-2">
                        <?php foreach($list_kelas as $kls) : ?>
                        <label class="relative">
                            <input type="checkbox" name="kelas_ampu[]" value="<?= $kls ?>" 
                                class="hidden peer cb-ampu" 
                                <?php if(in_array($kls, $kelas_aktif)) echo 'checked'; ?>>
                            <div class="cb-label text-[10px] font-black text-center py-2 border border-gray-800 rounded-lg text-gray-500 peer-checked:text-white">
                                <?= $kls ?>
                            </div>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <button type="submit" name="update" class="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:opacity-90 text-white font-black py-4 rounded-xl mt-8 transition-all uppercase text-[11px] tracking-widest shadow-lg shadow-purple-500/20">
                    Simpan Perubahan Data
                </button>
            </div>
        </form>
    </div>

</body>
</html>