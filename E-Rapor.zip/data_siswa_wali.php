<?php
session_start();
include 'koneksi.php';

// Fitur Pencarian
$search = "";
if (isset($_GET['cari'])) {
    $search = mysqli_real_escape_string($koneksi, $_GET['cari']);
}

// Cek apakah kolom nama_wali ada di tabel siswa untuk menghindari Error 500
$check_column = mysqli_query($koneksi, "SHOW COLUMNS FROM siswa LIKE 'nama_wali'");
$has_wali_column = mysqli_num_rows($check_column) > 0;

// Query ambil data
$query_siswa = "SELECT * FROM siswa WHERE 
                nama_siswa LIKE '%$search%' OR 
                nisn LIKE '%$search%' OR 
                kelas LIKE '%$search%' 
                ORDER BY kelas ASC, nama_siswa ASC";
$result = mysqli_query($koneksi, $query_siswa);

if (!$result) {
    die("Query Error: " . mysqli_error($koneksi));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Siswa | SMPN 110 Jakarta</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --bg: #000;
            --card: #0a0a0a;
            --border: #222;
            --purple: #a855f7;
            --text: #fff;
            --dim: #71717a;
        }
        body { font-family: 'Inter', sans-serif; background: var(--bg); color: var(--text); margin: 0; padding: 20px; }
        .container { max-width: 1200px; margin: 0 auto; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
        .back-btn { text-decoration: none; color: var(--dim); font-size: 0.85rem; display: flex; align-items: center; gap: 8px; }
        .search-box { background: var(--card); border: 1px solid var(--border); padding: 12px 20px; border-radius: 12px; display: flex; align-items: center; gap: 10px; margin-bottom: 20px; }
        .search-box input { background: transparent; border: none; color: white; width: 100%; outline: none; }
        .table-container { background: var(--card); border: 1px solid var(--border); border-radius: 12px; overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; min-width: 600px; }
        th { background: #0f0f0f; padding: 15px; text-align: left; font-size: 0.7rem; color: var(--dim); text-transform: uppercase; border-bottom: 1px solid var(--border); }
        td { padding: 15px; font-size: 0.85rem; border-bottom: 1px solid #111; }
        .badge-kelas { background: #1e3a8a; color: #60a5fa; padding: 3px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: bold; }
        .btn-edit { color: var(--purple); text-decoration: none; }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <a href="dashboard_admin.php" class="back-btn"><i class="fas fa-chevron-left"></i> Kembali</a>
        <h2 style="font-size: 1.1rem;">Manajemen Data Siswa</h2>
    </div>

    <form method="GET">
        <div class="search-box">
            <i class="fas fa-search" style="color: var(--dim);"></i>
            <input type="text" name="cari" placeholder="Cari NISN, Nama, atau Kelas..." value="<?= htmlspecialchars($search) ?>">
            <?php if($search != ""): ?>
                <a href="data_siswa_wali.php" style="color: var(--purple); text-decoration: none; font-size: 0.8rem;">Reset</a>
            <?php endif; ?>
        </div>
    </form>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Siswa / NISN</th>
                    <th>Kelas</th>
                    <th>Wali Murid</th>
                    <th style="text-align: center;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td>
                        <div style="font-weight: 600;"><?= strtoupper($row['nama_siswa']) ?></div>
                        <div style="font-size: 0.75rem; color: var(--dim);"><?= $row['nisn'] ?></div>
                    </td>
                    <td><span class="badge-kelas"><?= $row['kelas'] ?></span></td>
                    <td>
                        <?php if($has_wali_column): ?>
                            <div style="font-size: 0.85rem;"><?= $row['nama_wali'] ?: '-' ?></div>
                            <div style="font-size: 0.75rem; color: #22c55e;"><i class="fab fa-whatsapp"></i> <?= $row['no_hp_wali'] ?: '-' ?></div>
                        <?php else: ?>
                            <span style="color: var(--dim); font-style: italic; font-size: 0.75rem;">Kolom belum ada</span>
                        <?php endif; ?>
                    </td>
                    <td style="text-align: center;">
                        <a href="edit_siswa.php?id=<?= $row['id_siswa'] ?>" class="btn-edit">
                            <i class="fas fa-pen-to-square"></i>
                        </a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>