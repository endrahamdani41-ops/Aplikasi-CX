<?php
session_start();
include 'koneksi.php';

// 1. PROTEKSI & AMBIL SESSION (Disinkronkan dengan dashboard_guru.php Anda)
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: index.php");
    exit;
}

$nama_guru  = $_SESSION['nama'];
$kelas_wali = $_SESSION['kelas']; // Menggunakan 'kelas' sesuai dashboard Anda

// Jika guru bukan wali kelas (kelas kosong di session)
if (empty($kelas_wali)) {
    echo "<script>alert('Anda tidak memiliki akses cetak rapor karena bukan Wali Kelas.'); window.location='dashboard_guru.php';</script>";
    exit;
}

// 2. KONFIGURASI TANGGAL
$tgl_input = $_GET['tgl_rapor'] ?? date('Y-m-d');
function tgl_indo($tanggal){
    $bulan = [1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    $p = explode('-', $tanggal);
    return $p[2] . ' ' . $bulan[(int)$p[1]] . ' ' . $p[0];
}
$tgl_cetak = tgl_indo($tgl_input);

// 3. QUERY SISWA (Mengambil dari tabel 'siswa' berdasarkan kelas wali)
$query_siswa = mysqli_query($koneksi, "SELECT * FROM siswa WHERE kelas = '$kelas_wali' ORDER BY nama_murid ASC");
$jumlah_siswa = mysqli_num_rows($query_siswa);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cetak Rapor Masal Kelas <?= $kelas_wali ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;700&display=swap');
        @page { size: A4 portrait; margin: 0; }
        body { background-color: #050505; font-family: 'Plus Jakarta Sans', sans-serif; margin: 0; }
        
        /* Kontainer Kertas Rapor */
        .rapor-paper { 
            width: 210mm; min-height: 297mm; padding: 2cm; margin: 30px auto;
            background: white; color: black; box-shadow: 0 0 50px rgba(0,0,0,0.8);
            page-break-after: always; position: relative;
        }
        
        header { border-bottom: 3px double black; padding-bottom: 10px; margin-bottom: 25px; text-align: center; }
        .logo-dki { position: absolute; left: 2cm; top: 2cm; width: 60px; }
        
        table.nilai { width: 100%; border-collapse: collapse; margin-top: 20px; }
        table.nilai th, table.nilai td { border: 1px solid black; padding: 8px; text-align: center; font-size: 12px; }
        table.nilai th { background-color: #f3f4f6; font-weight: bold; }

        .no-print { position: sticky; top: 0; z-index: 100; background: rgba(10,10,10,0.9); backdrop-filter: blur(10px); border-bottom: 1px solid #1a1a1a; }
        
        @media print {
            body { background: none; }
            .no-print { display: none; }
            .rapor-paper { margin: 0; box-shadow: none; width: 100%; }
        }
    </style>
</head>
<body>

    <div class="no-print p-4 flex items-center justify-between px-10">
        <div class="flex items-center gap-4">
            <a href="dashboard_guru.php" class="text-gray-400 hover:text-white transition"><i class="fas fa-arrow-left"></i> Kembali</a>
            <h1 class="text-white font-bold uppercase tracking-tighter italic">Cetak Rapor Masal: <span class="text-purple-500"><?= $kelas_wali ?></span></h1>
        </div>
        <div class="flex items-center gap-6">
            <form method="GET" class="flex items-center gap-2 text-white text-xs">
                <span class="text-gray-500 uppercase font-black">Tanggal Rapor:</span>
                <input type="date" name="tgl_rapor" value="<?= $tgl_input ?>" onchange="this.form.submit()" class="bg-zinc-900 border border-zinc-800 p-1 rounded text-white">
            </form>
            <button onclick="window.print()" class="bg-purple-600 hover:bg-purple-500 text-white px-8 py-2 rounded-full font-black italic uppercase text-[10px] tracking-widest transition-all">
                <i class="fas fa-print mr-2"></i> Print (<?= $jumlah_siswa ?> Siswa)
            </button>
        </div>
    </div>

    <?php if($jumlah_siswa > 0): ?>
        <?php while($s = mysqli_fetch_array($query_siswa)): 
            $nis = $s['nis'];
        ?>
        <div class="rapor-paper">
            <header>
                <img src="https://upload.wikimedia.org/wikipedia/commons/9/9c/Logo_DKI_Jakarta.svg" class="logo-dki">
                <h1 class="text-xl font-bold uppercase tracking-tight">Laporan Hasil Penilaian Tengah Semester</h1>
                <h2 class="text-lg font-bold uppercase">SMP Negeri 110 Jakarta</h2>
                <p class="text-[10px] italic mt-1">Jl. Ekonomi No.1, RT.1/RW.8, Papanggo, Tj. Priok, Jakarta Utara</p>
            </header>

            <div class="grid grid-cols-2 text-xs mb-6">
                <table class="w-full">
                    <tr><td class="w-32 py-1">Nama Peserta Didik</td><td>: <strong><?= strtoupper($s['nama_murid']) ?></strong></td></tr>
                    <tr><td class="py-1">NIS / NISN</td><td>: <?= $nis ?> / -</td></tr>
                </table>
                <table class="w-full ml-10">
                    <tr><td class="w-24 py-1">Kelas</td><td>: <?= $s['kelas'] ?></td></tr>
                    <tr><td class="py-1">Semester</td><td>: 1 (Ganjil) / 2025-2026</td></tr>
                </table>
            </div>

            <table class="nilai">
                <thead>
                    <tr>
                        <th width="5%">No</th>
                        <th width="45%">Mata Pelajaran</th>
                        <th width="10%">PH 1</th>
                        <th width="10%">PH 2</th>
                        <th width="10%">PSTS</th>
                        <th width="15%">Rata-rata</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    // Ambil nilai dari tabel nilai_siswa yang disinkronkan oleh simpan_nilai.php
                    $q_nilai = mysqli_query($koneksi, "SELECT * FROM nilai_siswa WHERE nis = '$nis' ORDER BY mata_pelajaran ASC");
                    
                    if(mysqli_num_rows($q_nilai) > 0):
                        while($n = mysqli_fetch_assoc($q_nilai)): 
                            $rerata = ($n['formatif_ph1'] + $n['formatif_ph2'] + $n['sumatif_psts']) / 3;
                    ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td class="text-left font-bold"><?= $n['mata_pelajaran'] ?></td>
                        <td><?= $n['formatif_ph1'] ?></td>
                        <td><?= $n['formatif_ph2'] ?></td>
                        <td><?= $n['sumatif_psts'] ?></td>
                        <td class="bg-gray-50 font-bold"><?= round($rerata) ?></td>
                    </tr>
                    <?php endwhile; else: ?>
                    <tr><td colspan="6" class="p-10 italic text-gray-400">Data nilai untuk siswa ini belum diinput/disinkronkan.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <div class="mt-20 grid grid-cols-2 text-center text-sm">
                <div>
                    <p>Mengetahui,</p>
                    <p>Orang Tua/Wali Murid</p>
                    <div class="h-24"></div>
                    <p>( .................................... )</p>
                </div>
                <div>
                    <p>Jakarta, <?= $tgl_cetak ?></p>
                    <p>Wali Kelas <?= $s['kelas'] ?></p>
                    <div class="h-24"></div>
                    <p class="font-bold underline"><?= $nama_guru ?></p>
                    <p>NIP. <?= $_SESSION['nip'] ?? '-' ?></p>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="flex flex-col items-center justify-center py-60 text-zinc-700">
            <i class="fas fa-user-slash text-8xl mb-6"></i>
            <h2 class="text-3xl font-black italic uppercase">Siswa Tidak Ditemukan</h2>
            <p>Tidak ada data siswa untuk kelas <b><?= $kelas_wali ?></b> di database.</p>
        </div>
    <?php endif; ?>

</body>
</html>