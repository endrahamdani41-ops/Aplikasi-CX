<?php

$host = "sql301.infinityfree.com";
$user = "if0_41722130";
$pass = "Smpn110jkT";
$db = "if0_41722130_db_stok";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>