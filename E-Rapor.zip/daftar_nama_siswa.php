<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['login'])) { header("Location: login.php"); exit; }
$kelas_guru = $_SESSION['kelas']; 

// 1. FITUR DOWNLOAD BLANKO (Tetap .xls agar aman dibuka Excel)
if (isset($_GET['download_blanko'])) {
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=Blanko_Siswa_".$kelas_guru.".xls");
    echo '<table border="1"><tr><th>id</th><th>nama</th><th>nis</th><th>nisn</th><th>kelas</th><th>password</th></tr>
          <tr><td></td><td>NAMA SISWA</td><td>12345</td><td>00112233</td><td>'.$kelas_guru.'</td><td>12345</td></tr></table>';
    exit;
}

// 2. FITUR HAPUS SISWA
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($koneksi, "DELETE FROM nilaisiswa WHERE id='$id' AND kelas='$kelas_guru'");
    header("Location: daftar_nama_siswa.php");
}

// 3. PROSES IMPORT CSV (DETEKSI OTOMATIS)
if (isset($_POST['import'])) {
    $file = $_FILES['file_siswa']['tmp_name'];
    if (($handle = fopen($file, "r")) !== FALSE) {
        $header = fgets($handle); // Ambil baris pertama
        $separator = (strpos($header, ';') !== false) ? ';' : ','; // Deteksi otomatis ; atau ,
        rewind($handle); // Kembalikan ke baris awal
        fgetcsv($handle, 1000, $separator); // Lewati header
        
        $berhasil = 0;
        while (($data = fgetcsv($handle, 1000, $separator)) !== FALSE) {
            if (empty($data[1])) continue; // Lewati jika nama kosong
            $nama = mysqli_real_escape_string($koneksi, strtoupper($data[1]));
            $nis  = mysqli_real_escape_string($koneksi, $data[2]);
            $nisn = mysqli_real_escape_string($koneksi, $data[3]);
            
            $cek = mysqli_query($koneksi, "SELECT nis FROM nilaisiswa WHERE nis = '$nis'");
            if (mysqli_num_rows($cek) == 0) {
                $sql = "INSERT INTO nilaisiswa (nama, nis, nisn, kelas, password) 
                        VALUES ('$nama', '$nis', '$nisn', '$kelas_guru', '$nis')";
                if(mysqli_query($koneksi, $sql)) $berhasil++;
            }
        }
        fclose($handle);
        echo "<script>alert('$berhasil Siswa Berhasil Diimport!'); window.location='daftar_nama_siswa.php';</script>";
    }
}

// 4. TAMBAH MANUAL
if (isset($_POST['tambah'])) {
    $nama = mysqli_real_escape_string($koneksi, strtoupper($_POST['nama']));
    $nis  = mysqli_real_escape_string($koneksi, $_POST['nis']);
    $nisn = mysqli_real_escape_string($koneksi, $_POST['nisn']);
    mysqli_query($koneksi, "INSERT INTO nilaisiswa (nama, nis, nisn, kelas, password) VALUES ('$nama', '$nis', '$nisn', '$kelas_guru', '$nis')");
    header("Location: daftar_nama_siswa.php");
}

$query_siswa = mysqli_query($koneksi, "SELECT * FROM nilaisiswa WHERE kelas = '$kelas_guru' ORDER BY nama ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manajemen Siswa</title>
    <style>
        body { font-family: sans-serif; background: #f4f7f6; padding: 20px; }
        .container { max-width: 950px; margin: auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .card-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; }
        .card { padding: 15px; border: 1px solid #ddd; border-radius: 8px; background: #fdfdfd; }
        .btn { padding: 8px 12px; border-radius: 4px; border: none; cursor: pointer; color: white; text-decoration: none; font-weight: bold; font-size: 13px; }
        .btn-blue { background: #007bff; } .btn-green { background: #28a745; } .btn-red { background: #dc3545; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background: #007bff; color: white; }
    </style>
</head>
<body>
<div class="container">
    <div style="display:flex; justify-content:space-between; align-items:center;">
        <h2>Daftar Siswa Kelas <?php echo $kelas_guru; ?></h2>
        <a href="input_nilai.php" class="btn btn-blue">← Kembali ke Form Nilai</a>
    </div>

    <div class="card-grid">
        <div class="card">
            <strong>Massal (CSV)</strong><br>
            <a href="?download_blanko=true" class="btn btn-blue" style="display:block; margin:10px 0; text-align:center;">1. Download Blanko</a>
            <form method="POST" enctype="multipart/form-data">
                <input type="file" name="file_siswa" accept=".csv" required style="width:100%; margin-bottom:10px;">
                <button type="submit" name="import" class="btn btn-blue" style="width:100%;">2. Upload & Import</button>
            </form>
        </div>
        <div class="card">
            <strong>Tambah Manual</strong>
            <form method="POST">
                <input type="text" name="nama" placeholder="Nama Lengkap" required style="width:100%; padding:8px; margin:10px 0; border:1px solid #ccc;">
                <input type="text" name="nis" placeholder="NIS" required style="width:45%; padding:8px; border:1px solid #ccc;">
                <input type="text" name="nisn" placeholder="NISN" style="width:45%; padding:8px; border:1px solid #ccc;">
                <button type="submit" name="tambah" class="btn btn-green" style="width:100%; margin-top:10px;">Simpan Siswa</button>
            </form>
        </div>
    </div>

    <table>
        <thead><tr><th>No</th><th>Nama Siswa</th><th>NIS</th><th>NISN</th><th>Aksi</th></tr></thead>
        <tbody>
            <?php $no=1; while($s = mysqli_fetch_assoc($query_siswa)): ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><strong><?= $s['nama'] ?></strong></td>
                <td><?= $s['nis'] ?></td>
                <td><?= $s['nisn'] ?></td>
                <td><a href="?hapus=<?= $s['id'] ?>" class="btn btn-red" onclick="return confirm('Hapus siswa ini?')">Hapus</a></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>