<?php
include 'koneksi.php';

if (isset($_POST['upload_csv'])) {
    $file_tmp = $_FILES['file_csv']['tmp_name'];
    $handle = fopen($file_tmp, "r");
    
    // Ambil baris pertama untuk deteksi delimiter
    $first_line = fgets($handle);
    $separator = (substr_count($first_line, ';') > substr_count($first_line, ',')) ? ';' : ',';
    rewind($handle); // Kembalikan ke baris awal

    $berhasil = 0;
    $baris = 0;

    while (($data = fgetcsv($handle, 1000, $separator)) !== FALSE) {
        $baris++;
        if ($baris == 1) continue; // Lewati baris judul (header)

        // Sesuaikan index kolom: [0]=No, [1]=Nama, [2]=Kelas
        $nama = mysqli_real_escape_string($koneksi, strtoupper(trim($data[1])));
        $kelas = mysqli_real_escape_string($koneksi, trim($data[2]));

        if (!empty($nama) && !empty($kelas)) {
            $sql = "INSERT INTO nilaisiswa (nama, kelas) VALUES ('$nama', '$kelas')";
            if (mysqli_query($koneksi, $sql)) {
                $berhasil++;
            }
        }
    }
    fclose($handle);
    echo "<script>alert('Selesai! $berhasil data siswa berhasil ditambahkan.'); window.location='data_siswa.php';</script>";
}
?>