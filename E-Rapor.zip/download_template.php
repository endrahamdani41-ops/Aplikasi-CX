<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['login'])) { exit; }

$kelas = $_SESSION['kelas'];
$mapel_label = isset($_SESSION['mapel']) ? strtoupper($_SESSION['mapel']) : 'MAPEL';

// Nama file csv
$filename = "Blangko_Nilai_" . $mapel_label . "_Kelas_" . $kelas . ".csv";

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '";');

$output = fopen('php://output', 'w');
// Menambahkan BOM agar Excel membaca karakter dengan benar
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

// Header Kolom (Pastikan urutan ini diingat untuk proses_import)
fputcsv($output, array('NO', 'NIS', 'NAMA LENGKAP', 'PH1', 'PH2', 'ASTS', 'SAKIT', 'IZIN', 'ALFA'), ';');

$query = mysqli_query($koneksi, "SELECT nis, nama FROM nilaisiswa WHERE kelas='$kelas' ORDER BY nama ASC");
$no = 1;

while ($row = mysqli_fetch_assoc($query)) {
    fputcsv($output, array(
        $no++, 
        $row['nis'], 
        strtoupper($row['nama']), 
        '0', '0', '0', '0', '0', '0'
    ), ';');
}

fclose($output);
exit;