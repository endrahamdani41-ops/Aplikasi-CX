<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['login'])) {
    header("Location: login_guru.php");
    exit;
}

$kelas_wali = $_SESSION['kelas'] ?? '';

// LOGIKA SIMPAN
if (isset($_POST['simpan_absen'])) {
    foreach ($_POST['sakit'] as $nis => $sakit) {
        $izin = mysqli_real_escape_string($koneksi, $_POST['izin'][$nis]);
        $alpa = mysqli_real_escape_string($koneksi, $_POST['alpa'][$nis]);
        $sakit = mysqli_real_escape_string($koneksi, $sakit);
        
        $cek = mysqli_query($koneksi, "SELECT nis FROM absensi_siswa WHERE nis = '$nis'");
        if (mysqli_num_rows($cek) > 0) {
            mysqli_query($koneksi, "UPDATE absensi_siswa SET sakit = '$sakit', izin = '$izin', alpa = '$alpa' WHERE nis = '$nis'");
        } else {
            mysqli_query($koneksi, "INSERT INTO absensi_siswa (nis, sakit, izin, alpa) VALUES ('$nis', '$sakit', '$izin', '$alpa')");
        }
    }
    echo "<script>alert('Berhasil disimpan!'); window.location='absensi_siswa.php';</script>";
}

// AMBIL DATA
$query_siswa = mysqli_query($koneksi, "SELECT * FROM siswa WHERE kelas = '$kelas_wali'");

$data_siswa = [];
if ($query_siswa) {
    while ($row = mysqli_fetch_assoc($query_siswa)) {
        // --- LOGIKA PENCARIAN NAMA (SANGAT PENTING) ---
        // Kita cek satu per satu kemungkinan nama kolom yang ada di database Anda
        $nama_siswa = 'Tidak Ditemukan';
        
        if (isset($row['nama_peserta_didik'])) {
            $nama_siswa = $row['nama_peserta_didik'];
        } elseif (isset($row['nama'])) {
            $nama_siswa = $row['nama'];
        } elseif (isset($row['nama_siswa'])) {
            $nama_siswa = $row['nama_siswa'];
        } else {
            // Jika semua gagal, ambil kolom kedua setelah NIS (biasanya nama)
            $values = array_values($row);
            $nama_siswa = $values[1] ?? 'Tanpa Nama';
        }

        $row['nama_final'] = $nama_siswa;
        $data_siswa[] = $row;
    }
    
    // Urutkan berdasarkan nama yang sudah ditemukan
    usort($data_siswa, function($a, $b) {
        return strcmp($a['nama_final'], $b['nama_final']);
    });
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Input Absensi - Dark Mode</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #0f172a; color: #f1f5f9; margin: 0; padding: 20px; }
        .container { max-width: 1000px; margin: auto; background: #1e293b; padding: 30px; border-radius: 12px; border: 1px solid #334155; }
        h2 { color: #f1f5f9; border-bottom: 2px solid #3b82f6; padding-bottom: 15px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #334155; padding: 12px; text-align: center; }
        th { background: #334155; color: #94a3b8; text-transform: uppercase; font-size: 11px; }
        
        /* Input Angka Tanpa Spinner */
        input[type="number"] { 
            width: 60px; padding: 8px; background: #0f172a; border: 1px solid #475569; 
            border-radius: 5px; color: white; text-align: center; -moz-appearance: textfield;
        }
        input::-webkit-outer-spin-button, input::-webkit-inner-spin-button {
            -webkit-appearance: none; margin: 0;
        }

        .btn { padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; text-decoration: none; font-weight: bold; display: inline-flex; align-items: center; gap: 8px; }
        .btn-save { background: #3b82f6; color: white; float: right; margin-top: 20px; }
        .btn-back { background: #334155; color: white; margin-bottom: 15px; }
        tr:hover { background: #263349; }
        .nis-font { color: #94a3b8; font-family: monospace; font-weight: bold; }
    </style>
</head>
<body>
<div class="container">
    <a href="dashboard_guru.php" class="btn btn-back"><i class="fas fa-arrow-left"></i> Dashboard</a>
    <h2>Input Absensi Kelas: <?php echo htmlspecialchars($kelas_wali); ?></h2>
    <form method="POST">
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>NIS</th>
                    <th style="text-align: left;">Nama Peserta Didik</th>
                    <th>Sakit</th>
                    <th>Izin</th>
                    <th>Alpa</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $no = 1;
                foreach($data_siswa as $row): 
                    $nis = $row['nis'];
                    $d_absen = mysqli_query($koneksi, "SELECT * FROM absensi_siswa WHERE nis = '$nis'");
                    $a = mysqli_fetch_assoc($d_absen);
                ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td class="nis-font"><?php echo $nis; ?></td>
                    <td style="text-align: left;">
                        <strong><?php echo strtoupper($row['nama_final']); ?></strong>
                    </td>
                    <td><input type="number" name="sakit[<?php echo $nis; ?>]" value="<?php echo $a['sakit'] ?? 0; ?>" min="0"></td>
                    <td><input type="number" name="izin[<?php echo $nis; ?>]" value="<?php echo $a['izin'] ?? 0; ?>" min="0"></td>
                    <td><input type="number" name="alpa[<?php echo $nis; ?>]" value="<?php echo $a['alpa'] ?? 0; ?>" min="0"></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <button type="submit" name="simpan_absen" class="btn btn-save"><i class="fas fa-save"></i> SIMPAN DATA</button>
        <div style="clear: both;"></div>
    </form>
</div>
</body>
</html>