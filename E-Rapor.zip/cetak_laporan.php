<?php 
session_start();
include 'koneksi.php';
if (!isset($_SESSION['login'])) { header("Location: login.php"); exit; }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Cetak Laporan Stok</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body onload="window.print()">
    <div class="container mt-5">
        <h2 class="text-center">LAPORAN STOK BARANG</h2>
        <p class="text-center text-muted">Tanggal Cetak: <?php echo date('d-m-Y H:i'); ?></p>
        <table class="table table-bordered border-dark mt-4">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Barang</th>
                    <th>Stok Awal</th>
                    <th>Masuk</th>
                    <th>Keluar</th>
                    <th>Sisa Stok</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                $query = mysqli_query($conn, "SELECT * FROM barang");
                while($data = mysqli_fetch_array($query)){
                    echo "<tr>
                            <td>{$no}</td>
                            <td>{$data['nama_barang']}</td>
                            <td>{$data['stok_awal']}</td>
                            <td>{$data['barang_masuk']}</td>
                            <td>{$data['barang_keluar']}</td>
                            <td>{$data['stok_akhir']}</td>
                          </tr>";
                    $no++;
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>