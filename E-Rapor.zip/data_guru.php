<?php
session_start();
include 'koneksi.php';

// Proteksi Login Admin
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// 1. PROSES TAMBAH GURU
if (isset($_POST['tambah'])) {
    $nip = mysqli_real_escape_string($koneksi, $_POST['nip']);
    $nama_guru = mysqli_real_escape_string($koneksi, $_POST['nama_guru']);
    $mapel = mysqli_real_escape_string($koneksi, $_POST['mapel']);
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = mysqli_real_escape_string($koneksi, $_POST['password']);
    $wali_kelas = mysqli_real_escape_string($koneksi, $_POST['wali_kelas']); // Input Wali Kelas tunggal
    
    // Ambil array kelas ampu dari checkbox
    $kelas_ampu_array = isset($_POST['kelas_ampu']) ? $_POST['kelas_ampu'] : [];

    // Simpan ke tabel Guru (Wali Kelas disimpan di sini)
    $insert_guru = mysqli_query($koneksi, "INSERT INTO guru (nip, nama_guru, mapel, username, password, wali_kelas) 
                                         VALUES ('$nip', '$nama_guru', '$mapel', '$username', '$password', '$wali_kelas')");
    
    // Simpan ke tabel GURU_AMPU (Setiap kelas yang dicentang jadi 1 baris)
    if ($insert_guru && !empty($kelas_ampu_array)) {
        foreach ($kelas_ampu_array as $kls) {
            mysqli_query($koneksi, "INSERT INTO guru_ampu (nama_guru, kelas, mapel) 
                                   VALUES ('$nama_guru', '$kls', '$mapel')");
        }
    }

    if ($insert_guru) {
        header("Location: data_guru.php?status=sukses");
        exit;
    }
}

// 2. PROSES HAPUS GURU
if (isset($_GET['hapus'])) {
    $id_hapus = $_GET['hapus'];
    $get_name = mysqli_query($koneksi, "SELECT nama_guru FROM guru WHERE id = '$id_hapus'");
    $data_g = mysqli_fetch_assoc($get_name);
    if($data_g) {
        $nama_dihapus = $data_g['nama_guru'];
        mysqli_query($koneksi, "DELETE FROM guru WHERE id = '$id_hapus'");
        mysqli_query($koneksi, "DELETE FROM guru_ampu WHERE nama_guru = '$nama_dihapus'");
    }
    header("Location: data_guru.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Management Guru | E-Rapor</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap');
        body { background-color: #050505; color: white; font-family: 'Plus Jakarta Sans', sans-serif; }
        .glass-card { background: #0f0f0f; border: 1px solid #1a1a1a; border-radius: 20px; }
        .input-dark { background: #000; border: 1px solid #222; color: white; padding: 12px; border-radius: 12px; width: 100%; font-size: 13px; }
        .cb-label { transition: all 0.2s; border: 1px solid #222; }
        .cb-ampu:checked + .cb-label { background: #a855f7; border-color: #a855f7; color: white; box-shadow: 0 0 10px rgba(168, 85, 247, 0.3); }
        ::-webkit-scrollbar { width: 5px; height: 5px; }
        ::-webkit-scrollbar-thumb { background: #333; border-radius: 10px; }
    </style>
</head>
<body class="p-5 md:p-10">

    <div class="max-w-[1600px] mx-auto">
        <div class="flex justify-between items-center mb-8">
            <h1 class="text-2xl font-black italic tracking-tighter uppercase text-white">DATA <span class="text-purple-500 text-3xl">GURU</span></h1>
            <a href="dashboard_admin.php" class="bg-gray-900 border border-gray-800 px-5 py-2 rounded-xl text-[10px] font-bold hover:bg-white hover:text-black transition uppercase">Kembali</a>
        </div>

        <div class="flex flex-col lg:flex-row gap-6">
            <div class="w-full lg:w-[380px] shrink-0 space-y-6">
                <form action="" method="POST" class="space-y-6">
                    <div class="glass-card p-6 shadow-xl">
                        <h2 class="text-xs font-black text-gray-400 uppercase tracking-widest mb-6 italic italic"><i class="fas fa-id-card text-purple-500 mr-2"></i>Informasi Utama</h2>
                        <div class="space-y-4">
                            <input type="text" name="nip" class="input-dark" placeholder="NIP / No. Induk" required>
                            <input type="text" name="nama_guru" class="input-dark" placeholder="Nama Lengkap" required>
                            <input type="text" name="mapel" class="input-dark" placeholder="Mata Pelajaran" required>
                            
                            <div>
                                <label class="text-[9px] font-bold text-blue-400 uppercase ml-1">Tugas Wali Kelas</label>
                                <select name="wali_kelas" class="input-dark mt-1">
                                    <option value="-">Bukan Wali Kelas</option>
                                    <?php
                                    $kls_list = ['7A','7B','7C','7D','7E','7F','8A','8B','8C','8D','8E','8F','9A','9B','9C','9D'];
                                    foreach($kls_list as $k) echo "<option value='$k'>Wali Kelas $k</option>";
                                    ?>
                                </select>
                            </div>

                            <div class="grid grid-cols-2 gap-3">
                                <input type="text" name="username" class="input-dark" placeholder="User" required>
                                <input type="password" name="password" class="input-dark" placeholder="Pass" required>
                            </div>
                        </div>
                    </div>

                    <div class="glass-card p-6">
                        <h2 class="text-[10px] font-black text-purple-500 uppercase tracking-widest mb-4"><i class="fas fa-layer-group mr-2"></i>Pilih Kelas Ampu (Mengajar)</h2>
                        <div class="grid grid-cols-4 gap-2">
                            <?php foreach($kls_list as $kls) : ?>
                            <label class="relative cursor-pointer">
                                <input type="checkbox" name="kelas_ampu[]" value="<?= $kls ?>" class="hidden peer cb-ampu">
                                <div class="cb-label text-[10px] font-bold text-center py-2 rounded-lg text-gray-500">
                                    <?= $kls ?>
                                </div>
                            </label>
                            <?php endforeach; ?>
                        </div>
                        <button type="submit" name="tambah" class="w-full bg-purple-600 hover:bg-purple-700 text-white font-black py-4 rounded-xl mt-6 transition-all uppercase text-[11px] tracking-widest shadow-lg shadow-purple-500/20">
                            Simpan Data Guru
                        </button>
                    </div>
                </form>
            </div>

            <div class="flex-grow glass-card overflow-hidden h-fit">
                <div class="overflow-x-auto">
                    <table class="w-full text-left">
                        <thead>
                            <tr class="bg-gray-900/50 border-b border-gray-800 text-[10px] font-bold uppercase text-gray-400 tracking-wider">
                                <th class="p-5">Identitas</th>
                                <th class="p-5">Nama Guru</th>
                                <th class="p-5 text-center">Mapel</th>
                                <th class="p-5 text-center">Wali Kelas</th>
                                <th class="p-5 text-center">Kelas Ampu</th>
                                <th class="p-5 text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-900">
                            <?php 
                            $query = mysqli_query($koneksi, "SELECT * FROM guru ORDER BY nama_guru ASC");
                            while($row = mysqli_fetch_array($query)) {
                                // Logic ambil data ampu
                                $nama_g = $row['nama_guru'];
                                $q_ampu = mysqli_query($koneksi, "SELECT kelas FROM guru_ampu WHERE nama_guru = '$nama_g'");
                                $list_ampu = [];
                                while($da = mysqli_fetch_assoc($q_ampu)) { $list_ampu[] = $da['kelas']; }
                                $ampu_txt = !empty($list_ampu) ? implode(", ", $list_ampu) : "-";
                            ?>
                            <tr class="hover:bg-white/[0.02] transition">
                                <td class="p-5">
                                    <div class="text-white font-bold text-sm"><?= $row['nip'] ?></div>
                                    <div class="text-[9px] text-gray-500 font-bold uppercase">@<?= $row['username'] ?></div>
                                </td>
                                <td class="p-5 font-bold uppercase text-white text-[13px] tracking-tight"><?= $row['nama_guru'] ?></td>
                                <td class="p-5 text-center font-bold text-purple-400 italic text-[11px] uppercase"><?= $row['mapel'] ?></td>
                                
                                <td class="p-5 text-center">
                                    <span class="bg-blue-500/10 text-blue-400 text-[9px] px-3 py-1.5 rounded-lg border border-blue-500/20 font-black">
                                        <?= $row['wali_kelas'] ?: '-' ?>
                                    </span>
                                </td>

                                <td class="p-5 text-center">
                                    <span class="bg-purple-500/10 text-purple-400 text-[9px] px-3 py-1.5 rounded-lg border border-purple-500/20 font-black">
                                        <?= $ampu_txt ?>
                                    </span>
                                </td>

                                <td class="p-5">
                                    <div class="flex justify-center gap-2">
                                        <a href="edit_guru.php?id=<?= $row['id'] ?>" class="text-gray-500 hover:text-blue-400"><i class="fas fa-edit"></i></a>
                                        <a href="?hapus=<?= $row['id'] ?>" onclick="return confirm('Hapus guru ini?')" class="text-gray-500 hover:text-red-500"><i class="fas fa-trash"></i></a>
                                    </div>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</body>
</html>