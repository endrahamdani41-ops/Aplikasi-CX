<?php 
session_start();
if (!isset($_SESSION['login'])) { header("Location: login.php"); exit; }
?>

<?php 
include 'koneksi.php'; 
// ... (Logika PHP tetap sama seperti sebelumnya) ...
?>
<!DOCTYPE html>
<html>
<head>
    <title>Input Transaksi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header bg-success text-white">Input Transaksi Stok</div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Pilih Barang</label>
                            <select name="id_barang" class="form-select" required>
                                <option value="">-- Pilih --</option>
                                <?php
                                $tampil_barang = mysqli_query($conn, "SELECT id_barang, nama_barang FROM barang");
                                while($b = mysqli_fetch_array($tampil_barang)){
                                    echo "<option value='{$b['id_barang']}'>{$b['nama_barang']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tipe</label>
                            <select name="tipe" class="form-select">
                                <option value="masuk">Masuk (+)</option>
                                <option value="keluar">Keluar (-)</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Jumlah</label>
                            <input type="number" name="jumlah" class="form-control" min="1" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Keterangan</label>
                            <textarea name="keterangan" class="form-control" rows="2"></textarea>
                        </div>
                        <button type="submit" name="submit" class="btn btn-primary w-100">Simpan</button>
                        <a href="index.php" class="btn btn-secondary w-100 mt-2">Batal</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>