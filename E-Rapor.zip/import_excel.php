<?php
session_start();
include 'koneksi.php';

// 1. PAKSA TAMPILKAN ERROR (Agar tidak layar putih jika ada salah ketik)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['login'])) {
    header("Location: login_guru.php");
    exit;
}

if (isset($_POST['import'])) {
    $file = $_FILES['file_excel']['tmp_name'];
    
    // 2. CEK APAKAH FILE SUDAH DIPILIH
    if (!$file) {
        echo "<script>alert('Pilih file dulu!'); window.history.back();</script>";
        exit;
    }

    $zip = new ZipArchive;
    if ($zip->open($file) === TRUE) {
        $sharedStrings = [];
        if ($zip->locateName('xl/sharedStrings.xml') !== false) {
            $sharedStringsXml = simplexml_load_string($zip->getFromName('xl/sharedStrings.xml'));
            foreach ($sharedStringsXml->si as $val) {
                $sharedStrings[] = (string)$val->t;
            }
        }

        $sheetXml = simplexml_load_string($zip->getFromName('xl/worksheets/sheet1.xml'));
        $rows = $sheetXml->sheetData->row;

        // 3. MULAI TRANSAKSI (Biar cepet & gak membebani server)
        mysqli_query($koneksi, "START TRANSACTION");

        $count = 0;
        foreach ($rows as $index => $row) {
            if ($index < 2) continue; // Lewati header

            $data = array_fill(0, 36, "0"); 
            foreach ($row->c as $cell) {
                $ref = (string)$cell['r'];
                $colStr = preg_replace('/[0-9]/', '', $ref);
                $idx = 0;
                for ($i = 0; $i < strlen($colStr); $i++) {
                    $idx = $idx * 26 + (ord($colStr[$i]) - 64);
                }
                $idx--; 

                $v = (isset($cell->v)) ? (string)$cell->v : "0";
                if (isset($cell['t']) && (string)$cell['t'] == 's') {
                    $v = isset($sharedStrings[$v]) ? $sharedStrings[$v] : $v;
                }
                $data[$idx] = trim($v);
            }

            // Bersihkan NIS (Hanya angka)
            $nis = preg_replace('/[^0-9]/', '', $data[0]);
            
            if (!empty($nis) && is_numeric($nis)) {
                $nama  = mysqli_real_escape_string($koneksi, $data[1]);
                $kelas = mysqli_real_escape_string($koneksi, $data[2]);

                // Pastikan nilai adalah angka, jika kosong kasih 0
                for($i=3; $i<=35; $i++) {
                    $data[$i] = (is_numeric($data[$i])) ? $data[$i] : 0;
                }

                $sql = "REPLACE INTO nilaisiswa (
                    nis, nama, kelas, 
                    uh1_pai, uh2_pai, psts_pai, 
                    uh1_pp, uh2_pp, psts_pp, 
                    uh1_bind, uh2_bind, psts_bind, 
                    uh1_mtk, uh2_mtk, psts_mtk, 
                    uh1_ipa, uh2_ipa, psts_ipa, 
                    uh1_ips, uh2_ips, psts_ips, 
                    uh1_bing, uh2_bing, psts_bing, 
                    uh1_pjok, uh2_pjok, psts_pjok, 
                    uh1_inf, uh2_inf, psts_inf, 
                    uh1_sbk, uh2_sbk, psts_sbk, 
                    sakit, izin, alfa, nisn, password
                ) VALUES (
                    '$nis', '$nama', '$kelas', 
                    '{$data[3]}','{$data[4]}','{$data[5]}', 
                    '{$data[6]}','{$data[7]}','{$data[8]}', 
                    '{$data[9]}','{$data[10]}','{$data[11]}', 
                    '{$data[12]}','{$data[13]}','{$data[14]}', 
                    '{$data[15]}','{$data[16]}','{$data[17]}', 
                    '{$data[18]}','{$data[19]}','{$data[20]}', 
                    '{$data[21]}','{$data[22]}','{$data[23]}', 
                    '{$data[24]}','{$data[25]}','{$data[26]}', 
                    '{$data[27]}','{$data[28]}','{$data[29]}', 
                    '{$data[30]}','{$data[31]}','{$data[32]}', 
                    '{$data[33]}','{$data[34]}','{$data[35]}', '-', '12345'
                )";
                
                mysqli_query($koneksi, $sql);
                $count++;
            }
        }
        
        mysqli_query($koneksi, "COMMIT");
        $zip->close();
        echo "<script>alert('Sukses! $count data berhasil disinkronkan.'); window.location='dashboard_guru.php';</script>";
    } else {
        echo "<script>alert('Gagal membuka file Excel!'); window.location='dashboard_guru.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Import Nilai - E-Rapor</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #0d0d0d; color: white; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .card { background: #1a1a1a; padding: 40px; border-radius: 20px; border-top: 5px solid #6f42c1; width: 400px; text-align: center; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
        h2 { margin-bottom: 20px; }
        input[type="file"] { margin: 20px 0; color: #888; }
        .btn { background: #6f42c1; color: white; border: none; padding: 12px 25px; border-radius: 10px; cursor: pointer; width: 100%; font-weight: bold; }
        .btn:hover { background: #5a32a3; }
        .back { display: block; margin-top: 20px; color: #888; text-decoration: none; font-size: 0.9rem; }
    </style>
</head>
<body>
    <div class="card">
        <i class="fas fa-file-excel fa-4x" style="color: #6f42c1; margin-bottom: 20px;"></i>
        <h2>Import Nilai XLSX</h2>
        <form action="" method="post" enctype="multipart/form-data">
            <input type="file" name="file_excel" accept=".xlsx" required>
            <button type="submit" name="import" class="btn">PROSES SEKARANG</button>
        </form>
        <a href="dashboard_guru.php" class="back"><i class="fas fa-arrow-left"></i> Kembali</a>
    </div>
</body>
</html>