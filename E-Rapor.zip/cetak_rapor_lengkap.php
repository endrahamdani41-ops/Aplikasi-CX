<?php
session_start();
include 'koneksi.php';

$kelas_pilihan = isset($_GET['kelas']) ? mysqli_real_escape_string($koneksi, $_GET['kelas']) : '';

if (empty($kelas_pilihan)) {
    die("Pilih kelas terlebih dahulu.");
}

// 1. Ambil daftar siswa di kelas tersebut
$sql_siswa = "SELECT DISTINCT nis, nama_murid FROM nilai WHERE kelas = '$kelas_pilihan' ORDER BY nama_murid ASC";
$query_siswa = mysqli_query($koneksi, $sql_siswa);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Rapor Kolektif Kelas <?= $kelas_pilihan ?></title>
    <style>
        body { font-family: 'Arial', sans-serif; font-size: 12px; padding: 20px; }
        .lembar-rapor { page-break-after: always; border: 1px solid #000; padding: 20px; margin-bottom: 50px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #000; padding: 8px; text-align: center; }
        .text-left { text-align: left; }
        .header-rapor { text-align: center; margin-bottom: 20px; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body>

    <div class="no-print">
        <button onclick="window.print()" style="padding: 10px 20px; cursor:pointer;">🖨️ CETAK SEMUA RAPOR KELAS <?= $kelas_pilihan ?></button>
        <hr>
    </div>

    <?php 
    // 2. Looping setiap siswa untuk dibuatkan tabel mata pelajarannya
    while ($siswa = mysqli_fetch_array($query_siswa)) { 
        $nis = $siswa['nis'];
    ?>
    <div class="lembar-rapor">
        <div class="header-rapor">
            <h2>HASIL CAPAIAN KOMPETENSI PESERTA DIDIK</h2>
            <p>IDENTITAS SISWA: <strong><?= strtoupper($siswa['nama_murid']) ?></strong> (<?= $nis ?>) | KELAS: <?= $kelas_pilihan ?></p>
        </div>

        <table>
            <thead>
                <tr style="background: #eee;">
                    <th>NO</th>
                    <th class="text-left">MATA PELAJARAN</th>
                    <th>UH 1</th>
                    <th>UH 2</th>
                    <th>ASTS</th>
                    <th>RATA-RATA</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $no_mapel = 1;
                $total_rata = 0;
                $jumlah_mapel = 0;

                // 3. Ambil SEMUA MAPEL milik siswa ini (NIS ini)
                $sql_nilai = "SELECT * FROM nilai WHERE nis = '$nis' ORDER BY mapel ASC";
                $query_nilai = mysqli_query($koneksi, $sql_nilai);

                while ($n = mysqli_fetch_array($query_nilai)) { 
                    $rata = ($n['uh1'] + $n['uh2'] + $n['asts']) / 3;
                    $total_rata += $rata;
                    $jumlah_mapel++;
                ?>
                <tr>
                    <td><?= $no_mapel++ ?></td>
                    <td class="text-left"><?= $n['mapel'] ?></td>
                    <td><?= $n['uh1'] ?></td>
                    <td><?= $n['uh2'] ?></td>
                    <td><?= $n['asts'] ?></td>
                    <td><strong><?= number_format($rata, 1) ?></strong></td>
                </tr>
                <?php } ?>
            </tbody>
            <tfoot>
                <tr style="background: #f9f9f9; font-weight: bold;">
                    <td colspan="5">RATA-RATA NILAI KESELURUHAN</td>
                    <td>
                        <?php 
                        if ($jumlah_mapel > 0) {
                            echo number_format($total_rata / $jumlah_mapel, 1);
                        } else {
                            echo "0";
                        }
                        ?>
                    </td>
                </tr>
            </tfoot>
        </table>
    </div>
    <?php } ?>

</body>
</html>