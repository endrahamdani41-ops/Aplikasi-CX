<?php
session_start();
include 'koneksi.php';

// Menangkap parameter kelas dari URL
$kelas_pilihan = isset($_GET['kelas']) ? mysqli_real_escape_string($koneksi, $_GET['kelas']) : '';
$mapel = isset($_SESSION['mapel']) ? $_SESSION['mapel'] : 'MATA PELAJARAN';

// Validasi jika parameter kelas kosong
if (empty($kelas_pilihan)) {
    echo "<div style='text-align:center; padding:100px; font-family:sans-serif; background:#050505; color:white; min-height:100vh;'>
            <h2 style='color:#a855f7;'>⚠️ Data Kelas Tidak Ditemukan</h2>
            <p style='color:#666;'>Silakan pilih kelas terlebih dahulu melalui dashboard.</p>
            <br>
            <a href='dashboard_guru.php?page=input_nilai' style='color:white; background:#9333ea; padding:10px 20px; text-decoration:none; border-radius:10px;'>Kembali ke Pilih Kelas</a>
          </div>";
    exit;
}

// Query mengambil data nilai
$sql = "SELECT * FROM nilai WHERE kelas = '$kelas_pilihan' AND mapel = '$mapel' ORDER BY nama_murid ASC";
$query = mysqli_query($koneksi, $sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Nilai - <?= $kelas_pilihan ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap');
        
        /* Layout untuk Kertas */
        body { font-family: 'Times New Roman', serif; background: white; color: black; }
        
        .print-container { padding: 40px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid black; padding: 10px; text-align: center; font-size: 12px; }
        .text-left { text-align: left; padding-left: 15px; }
        
        /* Tombol Navigasi */
        .btn-nav {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 12px;
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 12px;
            font-weight: 800;
            text-transform: uppercase;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }
        
        .btn-home { background: #1a1a1a; color: white; }
        .btn-home:hover { background: #333; transform: translateY(-2px); }
        
        .btn-print { background: #9333ea; color: white; }
        .btn-print:hover { background: #7e22ce; transform: translateY(-2px); box-shadow: 0 10px 20px rgba(147, 51, 234, 0.2); }

        /* Media Print Control */
        @media print {
            .no-print { display: none !important; }
            body { background: white; }
            .print-container { padding: 0; }
        }
    </style>
</head>
<body class="bg-gray-50">

    <div class="no-print flex justify-between items-center bg-white border-b border-gray-200 p-6 shadow-sm">
        <a href="dashboard_guru.php?page=home" class="btn-nav btn-home">
            <i class="fas fa-home text-sm"></i> Beranda
        </a>
        
        <div class="flex gap-3">
            <button onclick="window.print()" class="btn-nav btn-print">
                <i class="fas fa-print text-sm"></i> Cetak Sekarang
            </button>
        </div>
    </div>

    <div class="print-container max-w-5xl mx-auto bg-white my-8 shadow-lg min-h-screen">
        <div style="text-align: center; border-bottom: 3px double black; padding-bottom: 20px; margin-bottom: 20px;">
            <h1 style="margin:0; font-size: 24px; font-weight: bold; text-transform: uppercase;">DAFTAR NILAI PESERTA DIDIK</h1>
            <h2 style="margin:5px 0; font-size: 18px; text-transform: uppercase;">SMP NEGERI 110 JAKARTA</h2>
            <p style="margin:0; font-size: 14px; italic">Tahun Pelajaran 2025/2026</p>
        </div>

        <div style="display: flex; justify-content: space-between; font-weight: bold; margin-bottom: 10px; font-size: 14px;">
            <div>Mata Pelajaran: <?= $mapel ?></div>
            <div>Kelas: <?= $kelas_pilihan ?></div>
        </div>

        <table>
            <thead>
                <tr style="background: #f2f2f2;">
                    <th width="5%">NO</th>
                    <th width="15%">NIS</th>
                    <th>NAMA PESERTA DIDIK</th>
                    <th width="10%">UH 1</th>
                    <th width="10%">UH 2</th>
                    <th width="10%">ASTS</th>
                    <th width="12%">RATA-RATA</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $no = 1;
                while($row = mysqli_fetch_array($query)) { 
                    $rata = ($row['uh1'] + $row['uh2'] + $row['asts']) / 3;
                ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td style="font-family: monospace;"><?= $row['nis'] ?></td>
                    <td class="text-left"><?= strtoupper($row['nama_murid']) ?></td>
                    <td><?= $row['uh1'] ?></td>
                    <td><?= $row['uh2'] ?></td>
                    <td><?= $row['asts'] ?></td>
                    <td style="font-weight: bold; background: #fafafa;"><?= number_format($rata, 1) ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>

        <div style="margin-top: 50px; float: right; width: 250px; text-align: center;">
            <p>Jakarta, <?= date('d F Y') ?></p>
            <p style="margin-bottom: 80px;">Guru Mata Pelajaran,</p>
            <p><b><?= strtoupper($nama_guru) ?></b></p>
            <hr style="border: 0; border-top: 1px solid black; margin-top: 0;">
        </div>
        <div style="clear: both;"></div>
    </div>

</body>
</html>