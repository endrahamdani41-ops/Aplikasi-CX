<?php
// Mengatur header agar browser mendownload sebagai file CSV
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=blangko_guru_rapor.csv');

// Membuka output stream
$output = fopen('php://output', 'w');

// Menambahkan instruksi pemisah (agar Excel otomatis mendeteksi tanda titik koma)
fputs($output, "sep=;\n");

// Menulis baris judul (Header) sesuai kolom di database Anda
// nip;nama_guru;mapel
fputcsv($output, array('nip', 'nama_guru', 'mapel'), ';');

fclose($output);
exit();
?>